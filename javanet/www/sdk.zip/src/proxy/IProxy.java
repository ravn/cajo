package proxy;

/*
 * A sample interface for demonstration proxy class of a cajo grail
 * server.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This interface is released into the public domain.
 * Written by John Catherino
 */

/**
 * This interface defines demonstration methods for an example proxy.
 * It is normally a starting point, to embellish with application specific
 * function definitions of your own.
 */
public interface IProxy {
   /**
    * Simply an example function. Normally a single remote service invocation
    * would result in multiple local service invocations, or manipulate large
    * local data objects.
    * @param arg An arbitrary string argument
    * @return An arbitrary string
    */
   String bar(String arg);
}
