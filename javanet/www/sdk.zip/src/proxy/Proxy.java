package proxy;

/*
 * An example proxy object for a cajo grail server.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino
 */

/**
 * This class creates a target service invocation proxy. The more work that
 * can be done here, the less network traffic there will be.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public final class Proxy extends util.AbstractProxy implements IProxy {
   // This is this interface on which the proxy will asynchronously
   // communicate with its remote service.
   private final HomeService homeProxy;
   // This is this interface on which the proxy will communicate with
   // its local service.
   private LocalService localProxy;
   // This defines the proxy's interface to its remote service. Only the
   // method signatures will be matched, therefore, the name and the
   // package of the interface do not matter.
   // Feel free to rename this interface to something more meaningful, as
   // it is referenced only from within this class. The interface need not
   // be declared in the same class as the proxy, and the remote service may
   // implement many more functions than the proxy specifies.
   private interface HomeService {
      Object foo(String bar);
   }
   // This defines the proxy's interface to its local service. Only the
   // method signatures will be matched, therefore, the name and the
   // package of the interface do not matter.
   // Feel free to rename this interface to something more meaningful, as
   // it is referenced only from within this class. The interface need not
   // be declared in the same class as the proxy, and the local service may
   // implement many more functions than the proxy specifies.
   private interface LocalService {
      Object foo(String bar);
   }
   /**
    * The constructor simply stores the reference to the sending service.
    * @param homeService A remote reference on which the proxy may
    * asynchronously communicate back with its sending service
    */
   public Proxy(Object homeService) {
      super(homeService);
//      homeProxy = proxy(homeService, service.IService.class); // tight coupling
      homeProxy = proxy(homeService, HomeService.class); // loose coupling
   }
   public void init(Object localService, gnu.cajo.Cajo cajo) {
      super.init(localService, cajo);
//      localProxy = proxy(localService, service.IService.class); // tight coupling
      localProxy = proxy(localService, LocalService.class); // loose coupling
      System.out.println("Proxy arrived at service!");
   }
   public String bar(String baz) { return localProxy.foo(baz).toString(); }
}

