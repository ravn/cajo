package proxy;

/*
 * An example proxy object for a cajo grail server.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino
 */

/**
 * This class creates a target service invocation proxy. The more work that
 * can be done here, the less network traffic there will be.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public final class Proxy extends util.AbstractBaseProxy implements IProxy {
   // This is this interface on which the proxy will communicate with
   // the local target service object.
   private MyInterface serviceProxy;
   // This defines the proxy's interface to the service item. Only
   // the method signatures will be matched, therefore, the name and the
   // package of the controller interface do not matter.
   // Feel free to rename this interface to something more meaningful, as
   // it is referenced only from within this class. It could also have used
   // the IService interface, if the class definition was in the proxy's
   // classpath, obviously, it need not.
   private interface MyInterface { // interface need not be in same class
      String getDescription(); // get service documentation
      Object foo(String bar); // this method is just an example
   } // functions solely of interest to the client, server may implement more
   /**
    * The constructor simply stores the reference to the sending service.
    * @param service A remote reference on which the proxy may asynchronously
    * communicate back with its service
    */
   public Proxy(Object service) { super(service); }
   public void init(Object service) {
      super.init(service);
// the following line creates a tight coupling between proxy and service
//      serviceProxy = proxy(service.IService.class); // tight coupling
// or, the coupling can be loose, using a proxy defined interface
      serviceProxy = proxy(MyInterface.class); // loose coupling
      System.out.println("Proxy arrived at service!");
   }
   public String bar(String arg) {
//      System.out.println(serviceProxy.getDescription()); // just for info
      return serviceProxy.foo(arg).toString();
   }
}

