package proxy;

/**
 * This class creates a target service invocation proxy. The more work that
 * can be done here, the less network traffic there will be.
 */
public final class Proxy extends util.AbstractProxy implements IProxy {
   // This is the reference on which the proxy will communicate with its
   // sending service.
   private final HomeService homeProxy;
   // This is the reference on which the proxy will communicate with its
   // receiving service.
   private LocalService localProxy;
   // This defines the proxy's interface to its sending service. Only the
   // method signatures will be matched, therefore, the name and the package
   // of the interface do not matter. Feel free to rename this interface to
   // something more meaningful, as it is referenced only from within this
   // class. The interface need not be declared in the same class as the
   // proxy, and the sending service may implement many more functions than
   // the proxy uses.
   private interface HomeService {
      Object foo(String bar);
   }
   // This defines the proxy's interface to its receiving service. Only the
   // method signatures will be matched, therefore, the name and the package
   // of the interface do not matter. Feel free to rename this interface to
   // something more meaningful, as it is referenced only from within this
   // class. The interface need not be declared in the same class as the
   // proxy, and the sending service may implement many more functions than
   // the proxy uses.
   private interface LocalService {
      Object baz(String foo);
   }
   /**
    * The constructor simply stores the reference to the sending service.
    * @param homeService A remote reference on which the proxy may
    * asynchronously communicate back with its sending service
    */
   public Proxy(Object homeService) {
      super(homeService);
//      homeProxy = proxy(homeService, service.IService.class); // tight coupling
      homeProxy = proxy(homeService, HomeService.class); // loose coupling
   }
   /**
    * This method provides a means to identify this proxy.
    * @return A identifier <i>(not description)</i> of the proxy
    */
   public String toString() { return "ExampleProxy"; }
   public void init(Object localService, gnu.cajo.Cajo cajo) {
      super.init(localService, cajo);
      localProxy = proxy(localService, LocalService.class);
      System.out.println("Proxy arrived at service!");
      // use the cajo object to connect to other services as needed
   }
   public String bar(String baz) { return localProxy.baz(baz).toString(); }
}
