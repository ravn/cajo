package controller;

/*
 * A sample interface for demonstration controller class of a cajo grail
 * server.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This interface is released into the public domain.
 * Written by John Catherino
 */

/**
 * This interface defines demonstration methods for an example controller.
 * It is normally a starting point, to embellish with application specific
 * function definitions of your own.
 */
public interface IController extends util.IController {
   /**
    * Simply an example function. Normally here is where pre and post
    * invocation details would be managed; such as caching, retry,
    * presentation, etc.
    * @param bar An arbitrary string argument
    * @return An arbitrary string
    * @throws RemoteException For network related failure or configuration
    * issues in attempting to communicate with the service
    */
   String baz(String bar) throws java.rmi.RemoteException;
}
