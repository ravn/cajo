package controller;

import view.View;

/*
 * An example controller object for a cajo grail server.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino
 */

/**
 * This class creates a controller, with an optional client GUI. It is
 * normally completely unaware of the <a href=https://cajo.dev.java.net>cajo</a>
 * grail framework. One role is to <i>map</i> its View object onto its
 * service object. It can be passed freely between clients, <i>however,</i>
 * it must be passed wrapped in a java.rmi.MarshalledObject. The receiver
 * would then call its get() method to extract the controller.<br>
 * <i><u>NB</u>:</i> the more work that can be done here at the controller,
 * the less busy, and ultimately more scalable, its corresponging service
 * will be.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public final class Controller extends util.AbstractController
   implements IController {
   // This is this interface on which the controller will communicate with
   // its service object asynchronously.
   private final MyService serviceProxy;
   // This defines the controller's interface to the service item. Only
   // the method signatures will be matched, therefore, the name and the
   // package of the controller interface do not matter.
   // Feel free to rename this interface to something more meaningful, as
   // it is referenced only from within this class. It could also have used
   // the IService interface, if the class definition was in the client's
   // classpath, obviously, it need not. The interface need not be declared
   // in the same class, and the remote service may specify more functions
   // than the controller specifies.
   private interface MyService {
      Object foo(String bar); // this method is just an example
   }
   /**
    * The constructor assigns the service reference, describes its
    * functionality, and creates a local proxy to its service.
    * @param service A remote reference to the service, over which the
    * controller may asynchronously communicate with it
    */
   public Controller(Object service) {
      super(service);
      description = // describe functionality of this controller
         "This is an example implementation of a cajo controller, it is " +
         "for illustrative purposes.";
      addDescriptor( // provide controller function description
         "foo", // function name
         "This function simply calls the service's function.", // description
         new String[][] { // arguments
            {  "java.lang.String", // argument type
               "An incoming argument, it will be appended to the response" +
               "string returned by this function." // description
            },
         },
         new String[] { // method return description
            "java.lang.String", // return type
            "An indicator of successful completion, it will have the " +
            "contents of the incoming string appended to it."
         }, new String[][] { // exceptions thrown by this function
            new String[] { "java.lang.NullPointerException", // type
               "Thrown simply as an example, service methods are free to " +
               "throw both checked and unchecked exceptions."
            }, RMIEXCEPTION, // standard network exception description
         }
      );
//      serviceProxy = proxy(service, service.IService.class); // tight coupling
      serviceProxy = proxy(service, MyService.class); // loose coupling
   }
   public util.AbstractView getView() throws java.io.IOException {
      // the view is hard-coded it could be read from a file, or a property
      view = new View();
      ((View)view).center.display("service call result:\n > ");
      try { ((View)view).center.display(foo("hello")); } // for illustration
      catch(java.rmi.RemoteException x) { x.printStackTrace(); }
      // attach controller specific view action listeners here...
      return view;
   }
   public String foo(String arg) throws java.rmi.RemoteException {
      return serviceProxy.foo(arg).toString();
   }
}
