package controller;

import view.View;
import java.util.concurrent.Future;

/**
 * This class defines an example controller, with an optional client GUI. It
 * is normally completely unaware of the <a href=https://cajo.dev.java.net>
 * cajo</a> grail framework.
 */
public final class Controller extends util.AbstractController
   implements IController {
   // This is the reference on which the controller will communicate with
   // its sending service
   private final Service serviceProxy;
   // This defines the controller's interface to its sending service. Only
   // the method signatures will be matched, therefore, the name and the
   // package of the controller interface do not matter. Feel free to rename
   // this interface to something more meaningful, as it is referenced only
   // from within this class. The interface need not be declared in the same
   // class, and the sending service may specify more functions than the
   // controller uses.
   private interface Service {
//      Object foo(String bar); // this method is just an example
      Future<String> foo(String bar); // invoke foo asynchronously
   }
   /**
    * The constructor assigns the service reference, describes its
    * functionality, and creates a local proxy to its {@link service.Service
    * service}.
    * @param service A remote reference to the service, over which the
    * controller may asynchronously communicate with it
    */
   public Controller(Object service) {
      super(service);
      description = // describe functionality of this controller
         "This is an example implementation of a cajo controller, it is " +
         "for illustrative purposes.";
      addDescriptor( // provide controller function description
         "baz", // function name
         "This function simply calls the service's function.", // description
         new String[][] { // arguments
            {  "java.lang.String", // argument type
               "An incoming argument, it will be appended to the response" +
               "string returned by this function." // description
            },
         },
         new String[] { // method return description
            "java.lang.String", // return type
            "An indicator of successful completion, it will have the " +
            "contents of the incoming string appended to it."
         }, new String[][] { // exceptions thrown by this function
            new String[] { "java.lang.NullPointerException", // type
               "Thrown simply as an example, if the argument is null; " +
               "service methods are free to throw both checked and " +
               "unchecked exceptions."
            }, RMIEXCEPTION, // standard network exception description
         }
      );
//      serviceProxy = proxy(service.IService.class); // tight coupling
      serviceProxy = proxy(Service.class); // loose coupling
   }
   /**
    * This method provides a means to identify this controller.
    * @return An identifier <i>(not a description)</i> of the controller
    */
   public String toString() { return "ExampleController"; }
   public void init(gnu.cajo.Cajo cajo) {
      super.init(cajo);
      System.out.println("Controller arrived at service!");
      // use the cajo object to connect to other services as needed
   }
   public util.AbstractView getView() throws java.io.IOException {
      // the view is hard-coded it could be read from a file, or a property
      view = new View();
      ((View)view).center.display("service call result:\n > ");
      try { ((View)view).center.display(baz("hello")); } // for illustration
      catch(Exception x) { x.printStackTrace(); }
      // attach controller specific view action listeners here...
      return view;
   }
   public String baz(String bar) throws Exception {
//      return serviceProxy.foo(bar).toString();
      Future<String> future = serviceProxy.foo(bar);
      return future.get(1, java.util.concurrent.TimeUnit.SECONDS);
      // it's silly to do a blocking get, periodically check isDone()
   }
}
