package controller;

import javax.swing.JComponent;

/*
 * An example controller object for a cajo grail server.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino
 */

/**
 * This class creates a controller, with an optional client GUI. It is
 * normally completely unaware of the <a href=https://cajo.dev.java.net>cajo</a>
 * grail framework. One role is to <i>map</i> its View object onto its
 * service object. <i><u>NB</u>:</i> the more work that can be done here at
 * the controller, the less busy, and ultimately more scalable, its
 * corresponging service will be.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public final class Controller extends util.BaseController
   implements IController {
   // This defines the controller's interface to the service item. Only
   // the method signatures will be matched, therefore, the name and the
   // package of the controller interface do not matter.
   // Declaration of exceptions is for the interest of the client, as they
   // will not be used when matching services. This means that a service
   // function may throw more or less exceptions than the client specifies.
   // Feel free to rename this interface to something more meaningful, as
   // it is referenced only from within this class. It could also have used
   // the IService interface, if the class definition was in the client's
   // classpath, obviously, it need not.
   private interface MyInterface { // interface need not be in same class
      String getDescription(); // get service documentation
      Object foo(String bar); // this method is just an example
   } // functions solely of interest to the client, server may implement more
   // This is this interface on which the controller will communicate with
   // its service object.
   private transient MyInterface serviceProxy;
   /**
    * The constructor simply assigns the description of its functionality.
    */
   public Controller() {
      description = // describe functionality of this controller
         "This is an example implementation of a cajo controller, it is " +
         "for illustrative purposes.";
   }
   public JComponent getView() throws java.io.IOException {
      try { System.out.println(foo("hello")); } // just for illustration
      catch(java.rmi.RemoteException x) { x.printStackTrace(); }
      JComponent view = new view.View();
// attach controller specific component action listeners here...
      return view;
   }
   /**
    * Simply an example function. Normally here is where pre and post
    * invocation details would be managed; such as caching, retry,
    * presentation, etc.
    * @param arg An arbitrary string argument
    * @return An arbitrary string
    * @throws RemoteException For network related failure or configuration
    * issues in attempting to communicate with the service
    */
   public String foo(String arg) throws java.rmi.RemoteException {
//      System.out.println(serviceProxy.getDescription()); // just for info
//      System.out.println(getDescription()); // show controller's info
      return serviceProxy.foo(arg).toString();
   }
   /**
    * This method is called once, by the BaseService, to assign the
    * controller's remote reference to it. Client specific interfaces to
    * the service object reference are normally created here.
    * @param service The reference to the remote <a href=https://cajo.dev.java.net>
    * cajo</a> service object
    */
   public void setService(Object service) {
      super.setService(service);
// the following line creates a tight coupling between controller and service
//      serviceProxy = proxy(service.IService.class); // tight coupling
// or, the coupling can be loose, using a client defined interface
      serviceProxy = proxy(MyInterface.class); // loose coupling
   }
   /**
    * This method provides a simple unit test of the GUI functionality,
    * it is intended for development and debug purposes only.
    * @param args No arguments are used in the unit test.
    * @throws Exception should the test startup fail, usually for missing
    * resource
    */
   public static void main(String args[]) throws Exception {
      new Controller().test(null);
   }
}
