/*
 * A typical startup module for a cajo grail server.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino
 */

/**
 * This class configures the JVM for network operation, and furnishes any
 * specified service objects for remote client use.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public final class Main {
   /**
    * This utility function is used to unit test a remote service
    * implementation. Once a reference to the service object is obtained,
    * a client can test its functionality against the functions of interest
    * to it. <br><i><u>NB</u>:</i> This function, as implemented cannot be
    * used in conjunction with the {@link #main main} function, as both
    * irrevocably and incompatibly configure the JVM network interface.
    * The <tt>main</tt> function configures the JVM as a server, where this
    * function configures the JVM as a client, to test a server.
    * @param url The address at which to find the service to test <i>(e.g.
    * //someHost:1198/main)</i>
    * @param serviceInterface The class name of the interface to be
    * emulated <i>(e.g. service.IService.class)</i>
    * @param clientHost the external server hostname or address if using
    * NAT, else null
    * @return An object implementing the service interface provided, yet
    * passing the function invocations directly on to the service object
    * @throws Exception If the server could not be reached, or the service
    * reference could not be obtained
    */
   @SuppressWarnings("unchecked") // sigh...
   public static <T> T testService(String url, Class serviceInterface,
      String clientHost) throws Exception {
      final String serverHost =
         java.net.InetAddress.getLocalHost().getHostAddress();
      gnu.cajo.invoke.Remote.config(serverHost, 0, clientHost, 0);
      Object proxy = gnu.cajo.invoke.Remote.getItem(url);
      return (T)gnu.cajo.utils.extra.TransparentItemProxy.
         getItem(proxy, new Class[] { serviceInterface });
   }
   /**
    * This utility function is used to unit test a remote service controller
    * implementation.
    * @param service The service reference typically obtained from the {@link
    * #testService testService} method.
    * @param controllerInterface The class name of the interface to be
    * emulated <i>(e.g. controller.IController.class)</i>
    * @return An object implementing the service interface provided, yet
    * passing the function invocations directly on to the controller object,
    * or <i>null,</i> if the service does not support a controller
    * @throws RemoteException If the controller request function failed, for
    * network related reasons
    */
   @SuppressWarnings("unchecked") // sigh...
   public static <T> T testController(util.IBaseService service,
      Class controllerInterface) throws java.rmi.RemoteException {
      Object controller = service.getController();
      return controller == null ? null :
         (T)gnu.cajo.utils.extra.TransparentItemProxy.
            getItem(controller, new Class[] { controllerInterface });
   }
   /**
    * The application creates a <a href=https://cajo.dev.java.net>cajo</a>
    * graphical service furnishing JVM. It will create and assign services
    * to registry names in code.<p>
    * The graphical client can be viewed in one of three ways:<ul>
    * <li>In the browser, by typing the server's <tt>address/name</tt>
    * <li>Via WebStart, by typing server's <tt>address/name/!</tt> in the
    * browser <i>(assuming the CodebaseServer is on port 80)</i>
    * <li>Via the client.jar application, by providing
    * <tt>//address:port[typically 1198]/name</tt> as its command line
    * argument</ul><br>
    * The default graphical client is named "main" and in that case, its name
    * can be omitted from the address if you wish.
    * @param args The startup can take up to four <i>optional</i>
    * configuration parameters, in order: (i.e. all previous options must
    * be provided)<ul>
    * <li><tt>args[0] - </tt>The server inbound port number <i>(typically
    * <a href=https://cajo.dev.java.net/servlets/NewsItemView?newsItemID=2539>
    * 1198</a>),</i> it will need to be opened if a firewall is in use
    * <li><tt>args[1] - </tt>The external client host address/name, if using
    * NAT.
    * <li><tt>args[2] - </tt>The internal client host address/name, if multi
    * home/NIC.
    * <li><tt>args[3] - </tt>The http server inbound port number.
    * <i>(typically 80),</i> it will need to be opened if a firewall is in
    * use</i></ul><p>
    * If this approach should prove too rigid, use of a properties file for
    * example, of <tt>registryName=Class.Name</tt>, could also work well,
    * possibly a GUI could be used, to request this information from the user.
    * <p><i><u>NB</u>:</i> If a server wishes to allow controllers to run
    * inside its JVM, via <tt>ItemServer.acceptProxies()</tt>it is <i>highly
    * recommended</i> to start the server with the following two -D arguments:<ul>
    * <li>-Djava.security.manager [lock down the JVM]
    * <li>-Djava.security.policy=service.policy [define controller permissions]</ul>
    * <br>*A functional example service.policy file is provided with the sdk,
    * see the build.xml <tt>startserver</tt> target for launch guidance.
    * @throws Exception should the server startup fail, usually for network
    * configuration related issues
    */
   public static void main(String args[]) throws Exception {
      gnu.cajo.Cajo.main(null); // optional, but just to be polite ;-)

//      util.Logger.CLASSOFF = true; // turn off logging for max performance

      // get configuration parameters, in this case from the command line...
      final int port = args.length > 0 ? Integer.parseInt(args[0]) : 1198; 
      final String clientHost = args.length > 1 ? args[1] : null;
      final String serverHost = args.length > 2 ? args[2] :
         java.net.InetAddress.getLocalHost().getHostAddress();
      final int httpPort = args.length > 3 ? Integer.parseInt(args[3]) : 8080;

      // now configure the *optional* codebase server for controllers/proxies
      new gnu.cajo.utils.CodebaseServer( // configure codebase service
         // these are the list of jars needed exclusively by clients
         new String[] { "client.jar", "grail.jar", "controller.jar" },
         httpPort, "util.Client", // set the server port, and client class
         "Example cajo graphical proxy", // web page title
         "The cajo project", // company identification
         "icon.gif", "splash.jpeg" // icon & splash screen
      ); // start codebase service first, if used, then create the cajo object

      util.AbstractBaseService.cajo =
         new gnu.cajo.Cajo(port, serverHost, clientHost);

// Important: comment the next line, unless you trust all of the users
//      gnu.cajo.utils.ItemServer.acceptProxies(); // accept service proxies?

      // create & name services here...
      new service.Service("main"); // main = default service
      // services use the cajo member object to lookup other needed services

      // finally output a little optional startup information...
      System.out.print("server started ");
      System.out.println(java.text.DateFormat.getDateTimeInstance(
         java.text.DateFormat.FULL, java.text.DateFormat.FULL).
            format(new java.util.Date()));
      System.out.print("internally operating on ");
      System.out.println(gnu.cajo.invoke.Remote.getDefaultServerHost());
      System.out.print("externally operating on ");
      System.out.println(gnu.cajo.invoke.Remote.getDefaultClientHost());
      System.out.print("services using TCP port ");
      System.out.println(gnu.cajo.invoke.Remote.getDefaultServerPort());
      System.out.print("http server on TCP port ");
      System.out.println(httpPort);
   }
}
