package service;

/**
 * This interface defines the demonstration methods for the example service.
 * It is normally a starting point, to embellish with application specific
 * function definitions of your own. A server can furnish as many services
 * as it wishes.
 */
public interface IService extends util.IService {
   /**
    * Simply an example function.
    * @param bar An arbitrary string argument
    * @return An arbitrary string
    * @throws Exception If the method invocation was rejected, for
    * application specific reasons
    * @throws java.rmi.RemoteException For network related failure or
    * configuration issues
    */
   String foo(String bar) throws Exception;
}
