package service;

/*
 * An example service object for a cajo grail server.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino
 */

/**
 * This class creates a service, with a optional corresponding controller. It
 * is normally completely unaware of the <a href=https://cajo.dev.java.net>cajo</a>
 * grail framework. It uses the static Cajo member of its inherited
 * service class, on which to find, and interact with other services.<br>
 * <i><u>NB</u>:</i> all public methods, <i>either static or instance,</i> will be
 * made publically invocable, so be careful: e.g. having a <tt>static
 * void main</tt> function would not be recommended. Generally this class is
 * used to aggregate application specific objects, selectively exposing and
 * handling their functionality.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public final class Service extends util.AbstractService
   implements IService, java.rmi.server.Unreferenced {
   /**
    * The constructor registers the service object in the local registry,
    * and boadcasts its availability through the <a href=http://weblogs.java.net/blog/cajo/archive/2007/09/simple_interjvm.html>
    * cajo federation</a>. The constructor can take arguments, there is no
    * artificial restriction that a service must have a no-arg constructor.
    * @param name The name under which to bind the service in the local
    * registry, this is what clients will use to obtain a reference if
    * calling on the registry directly
    * @throws Exception should the service startup fail, usually for network
    * configuration related issues
    */
   public Service(String name) throws Exception {
      // the controller below is hard-coded, it could be read from a file
      super("controller.Controller", name); // specify service controller
      description = // describe functionality of this service
         "This is an example implementation of a cajo service, it is " +
         "for illustrative purposes.";
      addDescriptor( // provide service function description
         "foo", // function name
         "This whimsical function does nothing important.", // description
         new String[][] { // arguments
            {  "java.lang.String", // argument type
               "An incoming argument, it will be appended to the response" +
               "string returned by this function." // description
            },
         },
         new String[] { // method return description
            "java.lang.String", // return type
            "An indicator of successful completion, it will have the " +
            "contents of the incoming string appended to it."
         }, new String[][] { // exceptions thrown by this function
            new String[] { "java.lang.NullPointerException", // type
               "Thrown simply as an example, if the argument is null. " +
               "service methods are free to throw both checked and " +
               "unchecked exceptions."
            }, RMIEXCEPTION, // network related exceptions can always occur
         }
      );
      // use cajo member object to connect to other services here, as needed
   }
   /**
    * Simply an example function. <i><u>NB</u>:</i> service methods can be
    * static, as well as instance. In this case, since we are extending
    * interfaces, the method cannot be declared static... pity.
    * @param bar An arbitrary string argument
    * @return An arbitrary string with the argument string appended
    * @throws NullPointerException If the provided argument is null, just
    * for illustrative purposes.
    */
   public String foo(String bar) {
      if (bar == null) throw new NullPointerException("null arg");
      return "foo invocation completed for " + bar;
   }
   /**
    * This method is called by the Java runtime when no client invocations
    * are pending for the moment. It can be used e.g. to unreference
    * lazily created objects, to return memory to the server JVM.<br>
    * As a <i>special</i> case, this public method <u>cannot</u> be called
    * remotely, if and only if, the service implements Unreferenced -- for
    * somewhat obvious reasons. Implementing Unreferenced is completely
    * optional. The implementation is purely for illustrative purposes.
    */
   public void unreferenced() {
      System.out.println(getClass().getName() + '@' +
         Integer.toHexString(hashCode()) +
            " is currently unreferenced by clients");
   }
}
