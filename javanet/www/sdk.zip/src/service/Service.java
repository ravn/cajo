package service;

/*
 * An example service object for a cajo grail server.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino 01-Dec-09
 */

/**
 * This class creates a service, with a corresponding client GUI. It is
 * normally completely unaware of the <a href=https://cajo.dev.java.net>cajo</a>
 * grail framework. It uses the static Cajo member of its inherited
 * BaseService class, on which to find, and interact with other services.<p>
 * <i>NB:</i> all public methods, <i>either static or instance,</i> will be
 * made publically invocable, so be careful: <i>e.g. a <tt>public static void
 * main</tt> function is not recommended.</i>
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public class Service extends util.BaseService {
   /**
    * The constructor registers the service object in the local registry,
    * and boadcasts its availability through the <a href=http://weblogs.java.net/blog/cajo/archive/2007/09/simple_interjvm.html>
    * cajo federation</a>. Note that the constructor can take arguments,
    * there is no artificial restriction that a service object must have a
    * no-arg constructor.
    * @param name The name under which to bind the service in the local
    * registry
    * @throws Exception should the service startup fail, usually for network
    * configuration related issues
    */
   public Service(String name) throws Exception {
      super("controller.Controller", name); // specify service controller
      description =
         "This is an example implementation of a cajo service, it is " +
         "for illustrative purposes.";
      addDescriptor( // provide a service function description
         "foo", // function name
         "This whimsical function does nothing important.", // description
         new String[][] { // arguments
            {  "java.lang.String", // argument type
               "An incoming argument, it will be appended to the response" +
               "string returned by this function." // description
            },
         },
         new String[] { // method return description
            "java.lang.String", // return type
            "An indicator of successful completion, it will have the " +
            "contents of the incoming string appended to it."
         }, new String[][] { // exceptions thrown by this function
            new String[] { "java.lang.NullPointerException", // type
               "Thrown simply as an example, service methods are free to " +
               "throw both checked and unchecked exceptions."
            }, RMIEXCEPTION, // network related exceptions can always occur
         }
      );
   }
   /**
    * Simply an example function. Note however, service methods can be
    * static, as well as instance. It will throw a NullPointerException
    * if the provided argument is null, just for illustrative purposes.
    */
   public static String foo(String arg) {
      if (arg == null) throw new NullPointerException("null arg");
      return "foo invocation completed for " + arg;
   }
}
