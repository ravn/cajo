/*
 * A typical startup module for a cajo grail server.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino
 */

/**
 * This class configures the JVM for network operation, and furnishes any
 * specified service objects for remote client use.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public final class Server extends util.AbstractServer {
   /**
    * The application creates a <a href=https://cajo.dev.java.net>cajo</a>
    * server.<br>
    * It has a graphical client that can be viewed in one of three ways:<ul>
    * <li>In the browser, by typing the server's <tt>address:port/name</tt>
    * <li>Via WebStart, by typing server's <tt>address:port/name/!</tt> in
    * the browser, or providing it as a hyperlink in another document
    * <li>Via the client.jar application, by providing
    * <tt>//address:port[typically 1198]/name</tt> as its command line
    * argument</ul><br>
    * The default graphical client is named "main" and in that case, its name
    * can be omitted from the address if you wish. See the build.xml file for
    * a good example for launching the client.
    * @param args The startup can take up to four <i>optional</i>
    * configuration parameters, in order: (i.e. all previous options must
    * be provided)<ul>
    * <li><tt>args[0] - </tt>The http server inbound port number.
    * <i>(typically 80),</i> it will need to be opened if a firewall is in
    * use</i></ul>
    * <li><tt>args[1] - </tt>The server inbound port number <i>(typically
    * <a href=https://cajo.dev.java.net/servlets/NewsItemView?newsItemID=2539>
    * 1198</a>),</i> it will need to be opened if a firewall is in use
    * <li><tt>args[2] - </tt>The external client host address/name, if using
    * NAT.
    * <li><tt>args[3] - </tt>The internal client host address/name, if multi
    * home/NIC.
    * <p>If this approach should prove too rigid, use of a properties file for
    * example, of <tt>registryName=Class.Name</tt>, could also work well,
    * possibly a GUI could be used, to request this information from the user.
    * <p><i><u>NB</u>:</i> If a server wishes to allow controllers or proxies
    * to run inside its JVM, via <tt>ItemServer.acceptProxies()</tt>it is
    * <i>highly recommended</i> to start the server with the following two
    * -D arguments:<ul>
    * <li>-Djava.security.manager [lock down the JVM]
    * <li>-Djava.security.policy=service.policy [define controller/proxy
    * permissions]</ul>
    * <br>*A functional example service.policy file is provided with the sdk,
    * see the build.xml <tt>startserver</tt> target for launch guidance.
    * @throws Exception should the server startup fail, usually for network
    * configuration related issues
    */
   public static void main(String args[]) throws Exception {

//      util.Logger.CLASSOFF = true; // turn off logging for max performance

      // get configuration parameters, in this case from the command line...
      final int httpPort = args.length > 0 ? Integer.parseInt(args[0]) : 80;
      final int port = args.length > 1 ? Integer.parseInt(args[1]) : 1198; 
      final String clientHost = args.length > 2 ? args[2] :
         java.net.InetAddress.getLocalHost().getHostAddress();
      final String serverHost = args.length > 3 ? args[3] :
         java.net.InetAddress.getLocalHost().getHostAddress();

      // configure the JVM TCP network interface
      gnu.cajo.invoke.Remote.config(serverHost, port, clientHost, port);

      // now start the *optional* codebase server for controllers/proxies
      codebaseServer = new gnu.cajo.utils.CodebaseServer(
         new String[] { "client.jar", "grail.jar" }, httpPort, "util.Client",
         "Example cajo graphical viewer", // frame title
         "The cajo project", // company identification
         "icon.gif", "splash.jpeg" // icon & splash screen
      );
      export("controller.jar", "proxy.jar"); // any jars needed by clients

      // finally create the cajo object
      cajo = new gnu.cajo.Cajo();

// Important: comment next optional line, unless you trust all of the users
//      gnu.cajo.utils.ItemServer.acceptProxies(); // accept moblie code?

      // create & name services here...
      new service.Service("main"); // main = default service
      // services use the cajo member object to combine other remote services

      // finally output a little optional startup information...
      System.out.print("server started ");
      System.out.println(java.text.DateFormat.getDateTimeInstance(
         java.text.DateFormat.FULL, java.text.DateFormat.FULL).
            format(new java.util.Date()));
      System.out.println("internally operating on " + serverHost);
      System.out.println("externally operating on " + clientHost);
      System.out.println("services using TCP port " + port);
      System.out.println("http server on TCP port " + httpPort);

      // The JVM is now free to run any program it wants locally as well.
      // The main application can make use of local & remote services.
      // As always, having a main application is completely optional.
   }
}
