package util;

/* Copyright 2010 John Catherino
 * The cajo project: https://cajo.dev.java.net
 *
 * Licensed under the Apache Licence, Version 2.0 (the "Licence"); you may
 * not use this file except in compliance with the licence. You may obtain a
 * copy of the licence at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the licence is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * This <i>internal use only</i> helper class is used by service classes to
 * decouple themselves from controllers and proxies. It may also be passed
 * freely between JVMs. It is normally obtained when requesting a controller
 * from a service; one is also typically sent to a JVM when installing a
 * proxy.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
final class ProxyLoader implements gnu.cajo.invoke.Invoke {
   private static final long serialVersionUID = 0L;
   private static final Class OBJECT[] = { Object.class };
   private final Object ref[];
   private transient String name;
   private transient Object object;
   private java.rmi.MarshalledObject<Class> mob;
   private void writeObject(java.io.ObjectOutputStream oos)
      throws java.io.IOException { // when serialising...
      if (mob == null) try { // lazily instantiate payload to conserve memory
         mob = new java.rmi.MarshalledObject<Class>(Class.forName(name));
      } catch(ClassNotFoundException x) { throw new java.io.IOException(x); }
      oos.defaultWriteObject();
   }
   @SuppressWarnings("unchecked") // sigh...
   private void readObject(java.io.ObjectInputStream ois)
      throws ClassNotFoundException, java.io.IOException {
      ois.defaultReadObject();
      try { object = mob.get().getConstructor(OBJECT).newInstance(ref); }
      catch(Exception x) { throw new java.io.IOException(x); }
   }
   /**
    * The constructor saves the details of the controller or proxy class to
    * instantiate for use at a remote JVM.
    * @param name The name of the controller or proxy class, e.g.
    * controller.Controller, or proxy.Proxy; this string can be hard-coded,
    * loaded from a file, a system property, even the command line
    * @param ref The remote reference to the service to be used by the
    * instance of the proxy or controller
    */
   ProxyLoader(String name, gnu.cajo.invoke.Remote ref) {
      this.name = name;
      this.ref  = new Object[] { ref };
   }
   /**
    * This method simply passes all method invocations onto the wrapped
    * controller or proxy object.
    * @param  method The name of method to invoke
    * @param args The arguments to provide to the method for its invocation,
    * if any
    * @return The sychronous data, if any, resulting from the invocation
    * @throws java.rmi.RemoteException For network communication related
    * reasons
    * @throws Exception If the wrapped object rejects the invocation, for
    * any application specific reason
    */
   public Object invoke(String method, Object args) throws Exception {
      return gnu.cajo.invoke.Remote.invoke(object, method, args);
   }
}
