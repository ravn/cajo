package util;

/*
 * A class transport for a cajo server.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino
 */

/**
 * This <i>internal use only</i> helper class is used by service classes to
 * decouple themselves from controllers and proxies. It represents an object
 * which will be instantiated locally on its first use. It may also be passed
 * freely between JVMs.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
final class ProxyLoader implements gnu.cajo.invoke.Invoke {
   private static final long serialVersionUID = 0L;
   private static final Class[] OBJECT = { Object.class };
   private final Object ref[];
   private java.rmi.MarshalledObject mob;
   private transient String name;
   private transient Object object;
   @SuppressWarnings("unchecked") // sigh...
   private void writeObject(java.io.ObjectOutputStream oos)
      throws java.io.IOException {
      if (mob == null) try { // lazily instantiate payload to conserve memory
         mob = new java.rmi.MarshalledObject(Class.forName(name));
      } catch(ClassNotFoundException x) { throw new java.io.IOException(x); }
      oos.defaultWriteObject();
   }
   /**
    * The constructor saves the details of the controller or proxy class to
    * instantiate for use at a remote JVM.
    * @param name The name of the controller or proxy class, e.g.
    * controller.Controller, or proxy.Proxy; this string can be hard-coded,
    * loaded from a file, or from a system property
    * @param ref The remote reference to the service or proxy to be used
    */
   ProxyLoader(String name, gnu.cajo.invoke.Remote ref) {
      this.name = name;
      this.ref  = new Object[] { ref };
   }
   /**
    * This method will instantiate the wrapped object on its first call, and
    * pass all invocations onto it.
    * @param  method The method to invoke on the internal object
    * @param args The arguments to provide to the method for its invocation
    * @return The sychronous data, if any, resulting from the invocation
    * @throws java.rmi.RemoteException For network communication related
    * reasons
    * @throws NoSuchMethodException If no matching method can be found
    * @throws Exception If the internal object rejects the request, for any
    * application specific reason
    */
   @SuppressWarnings("unchecked") // sigh...
   public Object invoke(String method, Object args) throws Exception {
      if (object == null) object= // create object first time used at client
         ((Class)mob.get()).getConstructor(OBJECT).newInstance(ref);
      return gnu.cajo.invoke.Remote.invoke(object, method, args);
   }
}
