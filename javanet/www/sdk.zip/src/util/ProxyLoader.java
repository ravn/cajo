package util;

import gnu.cajo.invoke.*;
import java.io.InputStream;
import java.io.ObjectInputStream;

/*
 * A class transport for a cajo server.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino
 */

/**
 * This <i>internal use only</i> helper class is used by service classes to
 * decouple themselves from controllers and proxies.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
final class ProxyLoader implements Invoke {
   private static final long serialVersionUID = 0L;
   private static final Class[] OBJECT = { Object.class };
   private final Object[] service;
   private final Class proxyClass;
   private transient Object proxy;
   /**
    * The constructor saves the details of the controller or proxy class to
    * instantiate for use at a remote JVM.
    * @param handle The name of the controller or proxy class, e.g.
    * controller.Controller, or proxy.Proxy; this string can be hard-coded,
    * loaded from a file, or from a system property
    * @param service The remote reference to the service or proxy to be used
    * @throws ClassNotFoundException If the name of the class provided cannot
    * be instantiated
    */
   ProxyLoader(String handle, Object service) throws ClassNotFoundException {
      proxyClass   = Class.forName(handle);
      this.service = new Object[] { service };
   }
   /**
    * This method will instantiate the object on its first call, and pass
    * all invocations onto it.
    * @param  method The method to invoke on the internal object
    * @param args The arguments to provide to the method for its invocation
    * @return The sychronous data, if any, resulting from the invocation
    * @throws java.rmi.RemoteException For network communication related
    * reasons
    * @throws NoSuchMethodException If no matching method can be found
    * @throws Exception If the internal object rejects the request, for any
    * application specific reason
    */
   @SuppressWarnings("unchecked") // sigh...
   public Object invoke(String method, Object args) throws Exception {
      if (proxy == null) // create proxy first time used at client
         proxy = proxyClass.getConstructor(OBJECT).newInstance(service);
      return Remote.invoke(proxy, method, args);
   }
   /**
    * This method simply overrides toString, to prepend that it is a
    * ProxyLoader, referencing a wrapped object.
    * @return String The name ProxyLoader-> prepended to the identification
    * of the wrapped object
    */
   public String toString() {
      return "ProxyLoader@" + Integer.toHexString(hashCode())+ "->" +
         proxyClass.getName();
   }
}
