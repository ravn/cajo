package util;

import gnu.cajo.invoke.*;
import java.io.InputStream;
import java.io.ObjectInputStream;

/*
 * A base controller class for a cajo grail server.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino
 */

/**
 * This <i>internal use only</i> helper class is used by service classes to
 * decouple themselves from controllers and proxies.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
final class ProxyLoader implements Invoke {
   private static final long serialVersionUID = 0L;
   private static final Class[] OBJECT = { Object.class };
   private final Class proxyClass;
   private final Object[] service = new Object[1];
   private transient Object proxy;
   /**
    * The constructor saves the name of the controller class to instantiate
    * for later use.
    * @param handle The name of the controller class, e.g. controller.Test
    * or proxy.Proxy
    * @throws ClassNotFoundException If the name of the class provided cannot
    * be instantiated
    */
   ProxyLoader(String handle) throws ClassNotFoundException{
      proxyClass = Class.forName(handle);
   }
   /**
    * Its first invocation is performed by the BaseService, to provide a
    * remote reference to itself, for controller callbacks.  The second
    * invocation dynamically instantiates the controller, via its no-arg
    * constructor. The constructed controller will have its setService
    * method invoked with a remote reference to the service object. After
    * this point, the ProxyLoader will and pass all subsequent invocations
    * to the created proxy itself.
    * @param  method The method to invoke on the internal object.
    * @param args The arguments to provide to the method for its invocation.
    * It can be a single object, an array of objects, or null.
    * @return The sychronous data, if any, resulting from the invocation.
    * @throws java.rmi.RemoteException For network communication related
    * reasons.
    * @throws NoSuchMethodException If no matching method can be found.
    * @throws Exception If the internal object rejects the request, for any
    * application specific reason.
    */
   @SuppressWarnings("unchecked") // sigh...
   public Object invoke(String method, Object args) throws Exception {
      if (service[0] == null && method.equals("setService")) {
         service[0] = args; // first call is always from service
         return null;
      } else if (proxy == null) // create proxy first time used at client
         proxy = proxyClass.getConstructor(OBJECT).newInstance(service);
      return Remote.invoke(proxy, method, args); // pass client call to proxy
   }
   /**
    * This method simply overrides toString, to prepend that it is a
    * ProxyLoader, referencing whatever its wrapped object returns from its
    * toString method.
    * @return String The name ProxyLoader-> prepended to the toString
    * returned by the wrapped object.
    */
   public String toString() {
      return "ProxyLoader@" + Integer.toHexString(hashCode())+ "->" +
         proxyClass.getName();
   }
}
