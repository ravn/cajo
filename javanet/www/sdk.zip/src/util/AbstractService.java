package util;

import gnu.cajo.invoke.Remote;
import gnu.cajo.utils.ItemServer;

/*
 * A base service class for a cajo grail server.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino
 */

/**
 * The service is a publicly invocable ordinary Java object. All of its
 * public methods, either <i>instance or static,</i> can be invoked by remote
 * JVMs. It is often recommended to use this class as a wrapper, exposing
 * specific methods of its internal utility objects.<br>
 * <i><u>NB</u>:</i> All service object instances must assume that they will
 * be used in a multi-threaded environment, therefore protection of
 * non-threadsafe regions is essential.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public abstract class AbstractService extends AbstractObject
   implements IService {
   private final Object controller;
   private final Remote serviceRef;
   private final Object initArgs[];
   private final String name;
   /**
    * This is the reference service instances and installed proxies and
    * controllers can use to look up other services needed to perform their
    * functionality, as needed.
    */
   protected final gnu.cajo.Cajo cajo;
   /**
    * The constructor will locally bind the service at its host under the
    * name provided, and join the <a href=http://weblogs.java.net/blog/cajo/archive/2007/09/simple_interjvm.html>
    * cajo federation</a>.
    * @param controller The class name of the <i>optional</i> controller to
    * instantiate upon arrival at the client JVM <i>(e.g.
    * controller.Controller)</i> it can be either hard-coded, read from a
    * file, or a system property.<br>
    * <i><u>NB</u>:</i> The handle can be null, if the service wishes to
    * provide no controller, nor GUI for clients.
    * @param name The name under which to bind the service in the local
    * rmi registry. These services can be then accessed through their
    * registry URL <i>(e.g. //myhost:1198/main)</i>.<br>
    * <i><u>NB</u>:</i> If a service already exists under this name, this
    * service will replace it.
    * @throws Exception if the service could not be successfully created,
    * normally for network configuration related issues
    */
   @SuppressWarnings("unchecked") // sigh...
   protected AbstractService(String controller, String name)
      throws Exception {
      descriptors.add(new Descriptor("getController",
         "This <i>canonical*</i> function is used to obtain a locally " +
         "running <i>smart</i> reference to the remote object. It allows " +
         "the server to offload some compute and memory load to the " +
         "client. It is not required for a client to request a service's " +
         "controller, and some services may not support controller objects " +
         "at all. However, requesting a service controller is considered " +
         "a <i>common courtesy.</i> Correspondingly, controllers should " +
         "take pains to minimise the compute and memory resources used of " +
         "the client.<br>*canonical meaning it is <i>expected</i> to " +
         "be implemented by <u>all</u> services",
         null, // method accepts no arguments
         new String[] { // return
            "java.lang.Object",
            "A locally running object create a reference to the actual " +
            "controller object. The object can be saved to storage, or " +
            "passed to other remote JVMs, to provide controllers to other " +
            "services.<br>" +
            "<i><u>Note</u>:</i> It may also be <tt>null,</tt> if the " +
            "service does not support controller objects."
         }, null // method throws no special exceptions
      ));
      descriptors.add(new Descriptor("acceptProxy",
         "This <i>canonical*</i> function is used to install client or " +
         "remote service proxies in this JVM. It allows local usage of the " +
         "service item in cases where network traffic could be greatly " +
         "reduced.<br>*canonical meaning it is <i>expected</i> to " +
         "be implemented by <u>all</u> services",
         new String[][] { // arguments
            new String[] {
               "java.lang.Object",
               "The client/remote service proxy object. Its <tt>init</tt> " +
               "method will be called, passing in a local reference to " +
               "the service object"
            },
         }, new String[] { // return
            "Object",
            "A remote reference to the proxy object on which the client " +
            "may communicate with it, in whatever manner it wishes",
            "returns, and possible thrown exceptions."
         }, new String[][] { // exceptions
            new String[] {
               "java.lang.NoSuchMethodException",
               "If the proxy does not implement a public <tt>init</tt> " +
               "method <i>(static or instance)</i>"
            }, new String[] {
               "java.lang.Exception",
               "Should the proxy reject the initialisation, for any proxy " +
               "specific reasons"
            }, RMIEXCEPTION, // standard java.rmi.RemoteException description
         }
      ));
      this.name = name;
      initArgs = new Object[] { this, AbstractServer.cajo };
      serviceRef =
//         new Remote(this); // no logging (fast)
         new Remote(new Logger (this, null)); // log remote use to console
      this.controller = controller == null ? null :
         new ProxyLoader(controller, serviceRef);
      cajo = AbstractServer.cajo;
      ItemServer.bind(this, name); // publish service for remote access
      cajo.export(this); // add service to cajo federation
   }
   /**
    * This method performs an emergency shutdown of the service if needed.
    * The service will no longer be usable by clients, but also the server.
    * A new instance must be constructed, to place the service back online.
    * <br><i><u>NB</u>:</i> If the service has accepted any proxies, they
    * <i>will</i> continue to function, as they have a reference to the
    * internal <i>local</i> service object instance.
    * @throws NoSuchObjectException If the service has already been killed.
    */
   protected final void kill() throws java.rmi.NoSuchObjectException {
      serviceRef.unexport(true);
      ItemServer.unbind(name);
   }
   /**
    * This method is used to send a proxy object to a remote service.
    * @param proxy The class name of the proxy to instantiate on arrival
    * at the remote service JVM <i>(e.g. proxy.Proxy)</i> it can be either
    * hard-coded, read from a file, or a system property
    * @param service The remote reference of the service to which to send
    * this proxy
    * @return A remote reference to the proxy operating at the target service
    * @throws Exception If the remote service does not accept proxy objects
    */
   protected final Object sendProxy(String proxy, Object service)
      throws Exception {
      ProxyLoader pl = new ProxyLoader(proxy, serviceRef);
      return Remote.invoke(service, "acceptProxy", pl);
   }
   /**
    * This method is used to request a controller object from a remote
    * service. The service reference is typically looked up using the
    * AbstractServer.cajo object. Otherwise it is obtained via the
    * Remote.getItem method; when the specific hostname, port, and service
    * name are known. <i>(As Client.main does)</i><br>
    * <i><u>NB</u>:</i> Accepting of controllers is disabled by default.
    * To enable acceptance of controllers <i>(and proxies)</i) uncomment the
    * <tt>ItemServer.acceptProxies()</tt> line in the main Server class.
    * @param service The remote reference to the service object from which
    * to request its controller
    * @return A local reference to the controller operating at this JVM,
    * or null, if the service does not furnish a controller
    * @throws java.rmi.RemoteException For network errors, or network
    * configuration issues
    */
   protected final Object getController(Object service) throws Exception {
      Object controller = Remote.invoke(service, "getController", null);
      if (controller == null) return null;
      Remote.invoke(controller, "init", AbstractServer.cajo);
      return controller;
   }
   /**
    * This method allows subclasses of AbstractService to dynamically cast a
    * remote proxy or local controller reference into an interface of its
    * choice. A proxy created for a remote proxy can be passed between JVMs,
    * if needed.
    * @param object A reference to a sent proxy or received controller
    * @param objectInterface The class of the interface to be implemented
    * <i>(e.g. somepkg.SomeInterface.class)</i>
    * @return An object implementing the interface provided, yet passing
    * the function invocations directly onto the object
    */
   @SuppressWarnings("unchecked") // sigh...
   protected final <T> T proxy(Object object, Class objectInterface) {
      return (T)gnu.cajo.utils.extra.TransparentItemProxy.
         getItem(object, new Class[] { objectInterface });
   }
   /**
    * This method provides a means to identify this service.
    * @return A identifier <i>(not description)</i> of the service
    */
   public String toString() { return "AbstractService"; }
   public Object acceptProxy(Object proxy) throws Exception {
      Remote.invoke(proxy, "init", initArgs);
      return new Remote(proxy).clientScope();
   }
   public final Object getController() { return controller; }
}
