package util;

import gnu.cajo.Cajo;
import gnu.cajo.invoke.Remote;
import gnu.cajo.utils.ItemServer;
import java.rmi.MarshalledObject;
import java.util.List;
import java.util.ArrayList;

/*
 * A base service class for a cajo grail server.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino
 */

/**
 * The service is a publicly invocable ordinary Java object. All of its
 * public methods, either <i>instance or static,</i> can be invoked by remote
 * JVMs. It is often recommended to use this class as a wrapper, exposing
 * specific methods of its internal utility objects.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public abstract class BaseService implements IBaseService {
   /**
    * This string provides a standard exeption description for Remote
    * Exceptions, caused by network errors. Since any remote method
    * invocation can throw one, it is provided here and recommended, for
    * convenient reuse.
    */
   protected static final String[] RMIEXCEPTION = {
      "java.rmi.RemoteException",
      "This exception is thrown implicitly whenever the function " +
      "invocation fails for network related reasons."
   };
   /**
    * This internal use only helper class is used to allow services to
    * describe their exposed methods to clients.
    * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
    * John Catherino</a>
    */
   private static final class Descriptor {
      private static final String NULLEXCEPTION[][] = { RMIEXCEPTION },
         NOARGS[][] = {{ "<i>void</i>", "This function takes no arguments" }},
         NORETURN[] = {  "<i>void</i>", "This function returns no value"   };
      private final String function;
      private final String description;
      private final String arguments[][];
      private final String retval[];
      private final String exceptions[][];
      private Descriptor(String function, String description,
         String arguments[][], String retval[], String exceptions[][]) {
         this.function    = function;
         this.description = description;
         this.arguments   = arguments  != null ? arguments  : NOARGS;
         this.retval      = retval     != null ? retval     : NORETURN;
         this.exceptions  = exceptions != null ? exceptions : NULLEXCEPTION;
      }
      private static String format(String description,
         List<Descriptor> descriptors) {
         StringBuffer sb = new StringBuffer("<h2>Service API:</h2>\r\n");
         sb.append(description);
         sb.append("\r\n<h3>Functions:</h3><ul>");
         for(Descriptor desc : descriptors) desc.describe(sb);
         sb.append("</ul>");
         return sb.toString();
      }
      private void describe(StringBuffer sb) {
         sb.append("\r\n<li><h4>");
         sb.append(function);
         sb.append("</h4>\r\n");
         sb.append(description);
         sb.append("<br><br>\r\n<table border=\"1\" width=\"100%\">\r\n" +
            "<tr align=\"left\" bgcolor=\"#E0E0E0\">\r\n" +
            "<th>Parameter</th>\r\n" +
            "<th>Type</th>\r\n" +
            "<th>Description</th>\r\n"
         );
         sb.append("<tr align=\"left\">\r\n<th rowspan=\"");
         sb.append(arguments.length);
         sb.append("\" bgcolor=\"#F0F0F0\">Arguments</th>\r\n");
         for (String argument[] : arguments) {
            sb.append("<td>");
            sb.append(argument[0]);
            sb.append("</td>\r\n<td>");
            sb.append(argument[1]);
            sb.append("</tr>\r\n");
         }
         sb.append("<tr align=\"left\">\r\n" +
            "<th bgcolor=\"#F0F0F0\">Return</th>\r\n<td>");
         sb.append(retval[0]);
         sb.append("</td>\r\n<td>");
         sb.append(retval[1]);
         sb.append("</td>\r\n<tr align=\"left\">\r\n<th rowspan=\"");
         sb.append(exceptions.length);
         sb.append("\" bgcolor=\"#F0F0F0\">Exceptions</th>\r\n");
         for (String exception[] : exceptions) {
            sb.append("<td>");
            sb.append(exception[0]);
            sb.append("</td>\r\n<td>");
            sb.append(exception[1]);
            sb.append("</tr>\r\n");
         }
         sb.append("</table>");
      }
   }
   private final Object loader;
   private MarshalledObject mob;
   private List<Descriptor> descriptors = new ArrayList<Descriptor>();
   /**
    * This string is reassigned by subclasses, to desribe the functionality
    * of this service, for clients. It is returned automatically as part of
    * the {@link #getDescription getDescription} string.
    */
   protected String description = "Service description currently undefined";
   /**
    * The constructor will locally bind the service at its host under the
    * name provided, and join the <a href=http://weblogs.java.net/blog/cajo/archive/2007/09/simple_interjvm.html>
    * cajo federation</a>.
    * @param handle The class name of the <i>optional</i> controller to
    * instantiate upon arrival at the client JVM. <i>(e.g.
    * controller.Controller)</i><br>
    * <i><u>NB</u>:</i> the handle can be null, if the service wishes to
    * provide no controller or GUI for clients.
    * @param name The name under which to bind the service in the local
    * rmi registry. These services can be then accessed through their
    * registry URL <i>(e.g. //myhost:1198/main)</i>.
    */
   protected BaseService(String handle, String name) throws Exception {
      loader = handle != null ? new ProxyLoader(handle) : null;
      descriptors.add(new Descriptor("getDescription",
         "This <i>canonical*</i> function is used to obtain an html " +
         "encoded string describing the functions furnished by this " +
         "service. Its format is invariant, to allow for automated " +
         "parsing, if desred. Please see <a href=https://cajo.dev.java.net>" +
         "the cajo project</a>, for further details.<br>*canonical " +
         "meaning it is <i>expected</i> to be implemented by <u>all</u> "+
         "services",
         null, // no arguments
         new String[] { // return
            "java.lang.String",
            "An html encoded document describing the functions " +
            "furnished, their functionality, argument requirements, " +
            "returns, and possible thrown exceptions."
         }, null // no special exceptions
      ));
      descriptors.add(new Descriptor("getController",
         "This <i>canonical*</i> function is used to obtain a locally " +
         "running <i>smart</i> reference to the remote object. It allows " +
         "the server to offload some compute and memory load to the " +
         "client. It is not required for a client to request a service's " +
         "controller, and some services may not support controller objects " +
         "at all. However, requesting a service controller is considered " +
         "a <i>common courtesy.</i> Correspondingly, controllers should " +
         "take pains to minimise the compute and memory resources used of " +
         "the client.<br>*canonical meaning it is <i>expected</i> to " +
         "be implemented by <u>all</u> services",
         null, // method accepts no arguments
         new String[] { // return
            "java.rmi.MarshalledObject",
            "A locally running object, contained within a MarshalledObject. " +
            "The service's controller is extracted into the client's " +
            "runtime, by calling its <tt>get();</tt> method. This will " +
            "create a reference to the actual controller object. The " +
            "MarshalledObject can be saved to storage, or passed to other " +
            "remote JVMs, to provide controllers to the service.<br>" +
            "<i><u>Note</u>:</i> It may also be <tt>null,</tt> if the " +
            "service does not support controller objects."
         }, null // method throws no special exceptions
      ));
      descriptors.add(new Descriptor("sendProxy",
         "This <i>canonical*</i> function is used to install client or " +
         "remote service proxies in this JVM. It allows local usage of the " +
         "service item in cases where network traffic could be greatly " +
         "reduced.<br>*canonical meaning it is <i>expected</i> to " +
         "be implemented by <u>all</u> services",
         new String[][] { // arguments
            new String[] {
               "java.rmi.MarshalledObject",
               "The client/remote service proxy object to extract and " +
               "instantiate at this JVM. Upon extraction, its " +
               "<tt>init</tt> method will be called, passing in a local " +
               "reference to the service object"
            },
         }, new String[] { // return
            "java.lang.Object",
            "A remote reference to the proxy object on which the client " +
            "may communicate with it, in whatever manner it wishes",
            "returns, and possible thrown exceptions."
         }, new String[][] { // exceptions
            new String[] {
               "java.lang.NoSuchMethodException",
               "If the proxy does not implement a public <tt>init</tt> " +
               "method <i>(static or instance)</i>"
            }, new String[] {
               "java.lang.Exception",
               "Should the proxy reject the initialisation, for any proxy " +
               "specific reasons"
            }, RMIEXCEPTION,
         }
      ));
      ItemServer.bind(this, name); // publish service for remote access
      cajo.export(this); // add service to cajo federation
   }
   /**
    * This method is used by subclasses to add their unique function
    * descriptions. The contents are returned via the {@link #getDescription
    * getDescription} method. The distinction between a method and a function
    * in this case, is that methods are related to the instance of a service
    * object, whereas a function is static to it. Since this is of no concern
    * to a client; the name function is used externally, and the disctinction
    * is only of significance internally.
    * @param function The name of the function
    * @param description An explanation of what this function does
    * @param arguments The descriptions of the arguments this function takes
    * the two-dimensional array is of pairs of argument class names, and
    * descriptions, <i>in order;</i> it can be null, if the function takes no
    * arguments
    * @param retval The description of the functional return, the first
    * element of the array is the class name or primitive type of the return,
    * the second element is the description; it can be null if the function
    * returns no value
    * @param exceptions The descriptions of the exceptions this function
    * throws, the two dimensional array is of pairs of exception class names,
    * and descriptions of their significance; it can be null, in which case
    * the standard RMIException description will be provided
    */
   protected void addDescriptor(String function, String description,
      String arguments[][], String retval[], String exceptions[][]) {
         descriptors.add(new Descriptor(function, description,
            arguments, retval, exceptions));
   }
   /**
    * This is the <a href=https://cajo.dev.java.net/nonav/docs/gnu/cajo/Cajo.html>
    * cajo</a> object by which service objects can publish themselves,
    * and search for other services via the <a href=http://weblogs.java.net/blog/cajo/archive/2007/09/simple_interjvm.html>
    * grail</a> framework.
    */
   public static Cajo cajo;
   public final String getDescription() {
      return Descriptor.format(description, descriptors);
   }
   public synchronized MarshalledObject getController() {
      if (mob == null && loader != null) try {
         Remote.invoke(loader, "setService",
//            new Remote(this)); // no logging (fast)
            new Remote(new Logger (this, null))); // log use to console
         mob = new MarshalledObject(loader);
      } catch(Exception x) {}
      return mob;
   }
   public Object sendProxy(MarshalledObject proxy) throws Exception {
      Object localProxy = proxy.get();
//      Remote.invoke(localProxy "init", this); // no proxy logging (fast)
      Remote.invoke(localProxy, "init", new Logger(this, null)); // log proxy
      return new Remote(proxy).clientScope(); // ref is used only by client
   }
}
