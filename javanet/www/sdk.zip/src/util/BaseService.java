package util;

import gnu.cajo.invoke.Remote;
import gnu.cajo.utils.ItemServer;
import java.rmi.MarshalledObject;

/*
 * A base service class for a cajo grail server.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino
 */

/**
 * The service is a publicly invocable ordinary Java object. All of its
 * public methods, either <i>instance or static,</i> can be invoked by remote
 * JVMs. It is often recommended to use this class as a wrapper, exposing
 * specific methods of its internal utility objects.<p>
 * <i><u>NB</u>:</i> all service object instances must assume that they will
 * be used by multiple clients, concurrently, therefore protection of
 * non-threadsafe regions is essential.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public abstract class BaseService extends BaseObject implements IBaseService {
   private transient final Object loader;
   private transient MarshalledObject mob;
   /**
    * The constructor will locally bind the service at its host under the
    * name provided, and join the <a href=http://weblogs.java.net/blog/cajo/archive/2007/09/simple_interjvm.html>
    * cajo federation</a>.
    * @param handle The class name of the <i>optional</i> controller to
    * instantiate upon arrival at the client JVM. <i>(e.g.
    * controller.Controller)</i><br>
    * <i><u>NB</u>:</i> the handle can be null, if the service wishes to
    * provide no controller or GUI for clients.
    * @param name The name under which to bind the service in the local
    * rmi registry. These services can be then accessed through their
    * registry URL <i>(e.g. //myhost:1198/main)</i>.
    */
   protected BaseService(String handle, String name) throws Exception {
      loader = handle != null ? new ProxyLoader(handle) : null;
      descriptors.add(new Descriptor("getController",
         "This <i>canonical*</i> function is used to obtain a locally " +
         "running <i>smart</i> reference to the remote object. It allows " +
         "the server to offload some compute and memory load to the " +
         "client. It is not required for a client to request a service's " +
         "controller, and some services may not support controller objects " +
         "at all. However, requesting a service controller is considered " +
         "a <i>common courtesy.</i> Correspondingly, controllers should " +
         "take pains to minimise the compute and memory resources used of " +
         "the client.<br>*canonical meaning it is <i>expected</i> to " +
         "be implemented by <u>all</u> services",
         null, // method accepts no arguments
         new String[] { // return
            "java.rmi.MarshalledObject",
            "A locally running object, contained within a MarshalledObject. " +
            "The service's controller is extracted into the client's " +
            "runtime, by calling its <tt>get();</tt> method. This will " +
            "create a reference to the actual controller object. The " +
            "MarshalledObject can be saved to storage, or passed to other " +
            "remote JVMs, to provide controllers to the service.<br>" +
            "<i><u>Note</u>:</i> It may also be <tt>null,</tt> if the " +
            "service does not support controller objects."
         }, null // method throws no special exceptions
      ));
      descriptors.add(new Descriptor("sendProxy",
         "This <i>canonical*</i> function is used to install client or " +
         "remote service proxies in this JVM. It allows local usage of the " +
         "service item in cases where network traffic could be greatly " +
         "reduced.<br>*canonical meaning it is <i>expected</i> to " +
         "be implemented by <u>all</u> services",
         new String[][] { // arguments
            new String[] {
               "java.rmi.MarshalledObject",
               "The client/remote service proxy object to extract and " +
               "instantiate at this JVM. Upon extraction, its " +
               "<tt>init</tt> method will be called, passing in a local " +
               "reference to the service object"
            },
         }, new String[] { // return
            "java.lang.Object",
            "A remote reference to the proxy object on which the client " +
            "may communicate with it, in whatever manner it wishes",
            "returns, and possible thrown exceptions."
         }, new String[][] { // exceptions
            new String[] {
               "java.lang.NoSuchMethodException",
               "If the proxy does not implement a public <tt>init</tt> " +
               "method <i>(static or instance)</i>"
            }, new String[] {
               "java.lang.Exception",
               "Should the proxy reject the initialisation, for any proxy " +
               "specific reasons"
            }, RMIEXCEPTION, // standard java.rmi.RemoteException description
         }
      ));
      ItemServer.bind(this, name); // publish service for remote access
      cajo.export(this); // add service to cajo federation
   }
   /**
    * This is the <a href=https://cajo.dev.java.net/nonav/docs/gnu/cajo/Cajo.html>
    * cajo</a> object by which service objects can publish themselves,
    * and search for other services via the <a href=http://weblogs.java.net/blog/cajo/archive/2007/09/simple_interjvm.html>
    * grail</a> framework.
    */
   public static transient gnu.cajo.Cajo cajo;
   @SuppressWarnings("unchecked") // sigh...
   public synchronized MarshalledObject getController() {
      if (mob == null && loader != null) try {
         Remote.invoke(loader, "setService",
//            new Remote(this)); // no logging (fast)
            new Remote(new Logger (this, null))); // log use to console
         mob = new MarshalledObject(loader);
      } catch(Exception x) {}
      return mob;
   }
   public Object sendProxy(MarshalledObject proxy) throws Exception {
      Object localProxy = proxy.get();
//      Remote.invoke(localProxy "init", this); // no proxy logging (fast)
      Remote.invoke(localProxy, "init", new Logger(this, null)); // log proxy
      return new Remote(proxy).clientScope(); // ref is used only by client
   }
}
