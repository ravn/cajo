package util;

/*
 * A base interface class for a cajo grail service.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino
 */

/**
 * This interface defines the fundamental method of a service proxy. A proxy
 * is sent from one service to another, to operate locally at it. This is to
 * both reduce network traffic, and improve performance. As a proxy needs
 * to know its receiving service interface, or at least part of it: a proxy
 * is typically custom-built, for a particular receiving service class.
 * <i>(much as to use its sending service)</i>
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public interface IProxy {
   /**
    * This method is invoked only once, by the receiving service on arrival.
    * It can be overridden to perform additional initialisation. However, if
    * this method is overridden, be sure to first call
    * <tt>super.init(localService, cajo);.</tt>
    * @param localService A local reference to the receiving service object
    * @param cajo The server's cajo reference, with which the proxy may
    * look up other services, or even export itself
    */
   void init(Object localService, gnu.cajo.Cajo cajo);
}
