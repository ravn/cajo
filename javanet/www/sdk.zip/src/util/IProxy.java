package util;

/*
 * A base interface class for a cajo grail service.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino
 */

/**
 * This interface defines the fundamental method of a service proxy. A proxy
 * is sent from one service to another, to operate locally at it. This is to
 * both reduce network traffic, and improve performance. Quite differently,
 * this interface is not used by the sending service but rather the receiver,
 * to initialise the proxy with a local reference to itself.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public interface IProxy {
   /**
    * This method is invoked only once, by the target service upon arrival.
    * After initialisation, the proxy can use the local service's static
    * cajo object, to lookup and interact with any other services it may
    * need. If this method is overridden, be sure to call
    * super.init(service);.
    * @param service A local reference to the target service object
    */
   void init(Object service);
}
