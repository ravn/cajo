package util;

import javax.swing.*;
import java.awt.event.*;
import java.rmi.registry.*;
import gnu.cajo.invoke.Remote;

/* Copyright 2010 John Catherino
 * The cajo project: https://cajo.dev.java.net
 *
 * Licensed under the Apache Licence, Version 2.0 (the "Licence"); you may
 * not use this file except in compliance with the licence. You may obtain a
 * copy of the licence at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the licence is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * The client is used to create a hosting JVM to receive a graphical
 * {@link AbstractController controller} {@link AbstractView view}v from a
 * <a href=https://cajo.dev.java.net>cajo</a> {@link AbstractService service}
 * JVM as an Applet, via WebStart, or as a stand-alone application.<p>
 * To use the client class to connect to a service directly, perform the
 * following:<br>
 * <tt><pre> java -cp client.jar:grail.jar util.Client //myHost:1198/main</tt></pre>
 * <i>(switch : to ; for windows users)</i><br><br>
 * <i><u>NB</u>:</i> This is a <b>special mode</b>. When clients operate this
 * way, the controllers will load with the <i>same</i> permissions as the
 * user who launched the client, rather than in the Applet/WebStart sandbox.
 * This can be very useful for special <i>"priviliged"</i> proxies, that
 * require more local access permissions. If you wish to run the client
 * locally, but keep proxies in a security sandbox, change the startup
 * invocation to the following:
 * <tt><pre> java -cp client.jar:grail.jar -Djava.security.manager
 * -Djava.security.policy=client.policy util.Client //myHost:1198/name</tt></pre>
 * *A functional example client.policy file is provided with the SDK.
 * See the build.xml <tt>startclient</tt> target for launch guidance.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public final class Client extends JApplet {
   private static Object proxy;
   /**
    * The default constructor performs no function.
    */
   public Client() {}
   /**
    * This method provides the standard mechanism to identify this client,
    * when it is running as an Applet.
    * @return The identification string for this client.
    */
   public String getAppletInfo() {
      return "cajo service view Applet, by John Catherino";
   }
   /**
    * This method describes the optional client parameters. There are two
    * such parameters which can be specified: <i>(normally these are set
    * automatically by the CodebaseServer class in gnu.cajo.utils)</i><p><ul>
    * <li>The <code>proxyName</code> parameter is the name of the service
    * object registered in the server's registry.
    * <li>The <code>proxyPort</code> parameter is the outbound port number on
    * which to contact the server.
    * <li>The <code>clientHost</code> parameter is the external domain name or
    * IP address the service must use to callback its controller.  It would
    * need to be specified if the client is operating behind a NAT router.
    * <li>The <code>clientHost</code> parameter is the external domain name or
    * IP address the server must use to callback its proxy.  It may need to
    * be specified if the client is operating behind a NAT router. Unspecified
    * it will be the client's default host address.
    * <li>The <code>clientPort</code> parameter is the external inbound port
    * number on which the server can contact its proxy. It may need to be
    * specified if the client is behind NAT, to map to the correct local port.
    * If a firewall is being used, it must be a permitted inbound port.
    * Unspecified, it will be the same as the local port value below.
    * <li>The <code>localPort</code> parameter is the internal inbound port
    * number on which the server can contact its proxy. It may need to be
    * specified if the client is behind NAT, to map to the correct remote port.
    * Unspecified, it will be anonymous.
    * </ul>
    * @return The parameter / information array.
    */
   public String[][] getParameterInfo() {
      return new String[][] {
         { "proxyName",  "String",  "Server's proxy's registry name" },
         { "proxyPort",  "Integer", "Server's proxy's port number"   },
         { "clientHost", "String",  "Client's external host name"    },
         { "clientPort", "Integer", "Client's external port number"  },
         { "localPort",  "Integer", "Client's internal port number"  },
      };
   }
   /**
    * This method is called when the client is created. It connects back to
    * its hosting server and requests the service designated in the URL.
    * Next it will invoke a getController() on the remote service reference
    * to request its controller. The returned local controller object will
    * have its getView() method invoked to obtain its graphical JComponent,
    * which will then be added into the JApplet via the Swing event dispatch
    * thread. The method invocation is then passed on to the view.
    */
    public void init() {
      try {
         String proxyName  = getParameter("proxyName");
         String proxyPort  = getParameter("proxyPort");
         String clientHost = getParameter("clientHost");
         String clientPort = getParameter("clientPort");
         String localPort  = getParameter("localPort");
         int pPort = proxyPort  != null ? Integer.parseInt(proxyPort)  : 1099;
         int cPort = clientPort != null ? Integer.parseInt(clientPort) : 0;
         int lPort = localPort  != null ? Integer.parseInt(localPort)  : 0;
         if (proxyName == null) proxyName = "main";
         Remote.config("0.0.0.0", lPort, clientHost, cPort);
         proxy = LocateRegistry.getRegistry(getCodeBase().getHost(), pPort);
         proxy = ((Registry)proxy).lookup(proxyName);
         proxy = Remote.invoke(proxy, "getController", null);
         proxy = Remote.invoke(proxy, "getView", null);
         SwingUtilities.invokeAndWait(new Runnable() {
            public void run() {
               try {
                  getContentPane().add((JComponent)proxy);
                  try { Remote.invoke(proxy, "init", null); }
                  catch(Exception x) {}
                  validate();
               } catch(Exception x) { showStatus(x.getLocalizedMessage()); }
            }
         });
      } catch(Exception x) { showStatus(x.getLocalizedMessage()); }
   }
   /**
    * This method is called each time the Client becomes visible, the method
    * invocation is then passed on to the view.
    */
   public void start() {
      try { Remote.invoke(proxy, "start", null); } catch(Exception x) {}
   }
   /**
    * This method is called each time the Client becomes invisible, the
    * method invocation is then passed on to the view.
    */
   public void stop() {
      try { Remote.invoke(proxy, "stop", null); } catch(Exception x) {}
   }
   /**
    * This method is called when the Client is disposed, the method
    * invocation is then passed on to the view.
    */
   public void destroy() {
      try { Remote.invoke(proxy, "destroy", null); } catch(Exception x) {}
   }
   /**
    * The application creates a graphical Component proxy hosting VM. With the
    * URL argument provided. It will use the static <tt>Remote.getItem</tt>
    * method of the Remote class to contact the service. Next it will invoke
    * getController() on the remote service reference to request its local
    * controller. The returned object will have its getView method invoked to
    * obtain its graphical JComponent view, which will then be added into a
    * JFrame via the Swing event dispatch thread. Finally an init() method
    * invocation is passed on to the view.<p>
    * When using the Client from the command line, it is possible to
    * optionally set the Client frame title explicitly. To do this, simply
    * type:<br><br><tt>
    * java -cp grail.jar;client.jar -Dutil.Client.title="My Frame Title"
    * util.Client //myHost:1198/test</tt><p>
    * <i><u>NB</u>:</i> When running Client as an application (<i><u>except</u>
    * via WebStart/Applet</i>) it will run at the <b>same</b> level of priviliges
    * as the process that started it. This is useful for example, when a
    * special, administrative process needs to be run locally. It can also be
    * used when a machine wishes to aid a service, offering up its computing
    * resources.
    * @param args The startup requires one mandatory, and up to four optional
    * configuration parameters, in this order:<ul>
    * <li><tt>args[0] - </tt>The URL where to get the graphical proxy item:<br>
    * file:// http:// ftp:// ..., //host:port/name (rmiregistry), /path/name
    * (serialized), or path/name (class).
    * <li><tt>args[1] - </tt>The optional external client port number,
    * if using NAT.
    * <li><tt>args[2] - </tt>The optional external client host name,
    * if using NAT.
    * <li><tt>args[3] - </tt>The optional internal client port number,
    * if using NAT.
    * <li><tt>args[4] - </tt>The optional internal client host name,
    * if multi home/NIC.</ul>
    * @throws Exception And subclasses, for a multitude of reasons
    */
   public static void main(final String args[]) throws Exception {
      if (System.getSecurityManager() == null)
         System.setSecurityManager(new SecurityManager() {
            public void checkPermission(java.security.Permission perm) {}
         });  // give loaded controllers FULL permissions
      if (args.length > 0) { // parse command line arguments
         int clientPort    = args.length > 1 ? Integer.parseInt(args[1]) : 0;
         String clientHost = args.length > 2 ? args[2] : null;
         int localPort     = args.length > 3 ? Integer.parseInt(args[3]) : 0;
         String localHost  = args.length > 4 ? args[4] : "O.O.O.O";
         Remote.config(localHost, localPort, clientHost, clientPort);
         proxy = Remote.getItem(args[0]); // fetch service by URL
         proxy = Remote.invoke(proxy, "getController", null);
         proxy = Remote.invoke(proxy, "getView", null);
         SwingUtilities.invokeLater(new Runnable() {
            public void run() {
               String title = null;
               try { title = System.getProperty("util.Client.title"); }
               catch(Exception x) {} // won't work running in WebStart
               if (title == null) title = "cajo Viewer";  // default
               JFrame frame = new JFrame(title + '-' + args[0]);
               frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
               frame.getContentPane().add((JComponent)proxy);
               frame.pack();
               frame.addWindowListener(new WindowListener() {
                  public void windowOpened(WindowEvent we) {
                     try { Remote.invoke(proxy, "init", null); }
                     catch(Exception x) {}
                  }
                  public void windowDeiconified(WindowEvent we) {
                     try { Remote.invoke(proxy, "start", null); }
                     catch(Exception x) {}
                  }
                  public void windowIconified(WindowEvent we) {
                     try { Remote.invoke(proxy, "stop", null); }
                     catch(Exception x) {}
                  }
                  public void windowClosed(WindowEvent we) {
                     try { Remote.invoke(proxy, "destroy", null); }
                     catch(Exception x) {}
                  }
                  public void windowActivated(WindowEvent we) {}
                  public void windowDeactivated(WindowEvent we) {}
                  public void windowClosing(WindowEvent we) {}
               });
               frame.setVisible(true);
            }
         });
      } else System.err.println("service URL required e.g. //host:port/name");
   }
}
