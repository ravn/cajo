package util;

import gnu.cajo.invoke.Remote;
import gnu.cajo.utils.CodebaseServer;
import gnu.cajo.utils.extra.TransparentItemProxy;

/* Copyright 2010 John Catherino
 * The cajo project: https://cajo.dev.java.net
 *
 * Licensed under the Apache Licence, Version 2.0 (the "Licence"); you may
 * not use this file except in compliance with the licence. You may obtain a
 * copy of the licence at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the licence is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * The server base class provides two utility methods to test remote services
 * and their controllers, and a method to optionally export any mobile code
 * needed for its {@link AbstractProxy proxy} or {@link AbstractController
 * controller} objects.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public abstract class AbstractServer {
   static { // optional, but just to be polite ;-)
      try { gnu.cajo.Cajo.main(null); } catch(java.io.IOException x) {}
   }
   /**
    * An optional <a href=https://cajo.dev.java.net/nonav/docs/gnu/cajo/utils/CodebaseServer.html>
    * CodebaseServer</a>, which would be used to furnish mobile codebases for
    * controllers and proxies, if needed.
    */
   protected static CodebaseServer codebaseServer;
   /**
    * This is the <a href=https://cajo.dev.java.net/nonav/docs/gnu/cajo/Cajo.html>
    * cajo</a> object with which service, controller, and proxy objects can
    * export themselves, and search for other services via the <a href=http://weblogs.java.net/blog/cajo/archive/2007/09/simple_interjvm.html>
    * grail</a> framework.
    */
   protected static gnu.cajo.Cajo cajo;
   /**
    * The default constructor performs no function.
    */
   protected AbstractServer() {}
   /**
    * This utility function is used to unit test a remote service
    * implementation. Once a reference to the service object is obtained,
    * a client can test its functionality against the functions of interest
    * to it. <br><i><u>NB</u>:</i> This function configures the JVM as a
    * client, for test purposes, not as a server.
    * @param serviceInterface The class name of the interface to be
    * implemented <i>(e.g. service.IService.class)</i>
    * @param url The address at which to find the service to test <i>(e.g.
    * //someHost:1198/main)</i>
    * @param clientHost the external server hostname or address if using
    * NAT, else null
    * @return An object implementing the service interface provided, yet
    * passing the function invocations directly on to the service object
    * @throws Exception If the server could not be reached, or the service
    * reference could not be obtained
    */
   @SuppressWarnings("unchecked") // sigh...
   protected static final <T> T testService(Class serviceInterface,
      String url, String clientHost) throws Exception {
      Remote.config("0.0.0.0", 0, clientHost, 0);
      Object service = Remote.getItem(url);
      return (T)TransparentItemProxy.getItem(service,
         new Class[] { serviceInterface });
   }
   /**
    * This utility function is used to unit test a remote service controller
    * implementation.
    * <br><i><u>NB</u>:</i> methods can be invoked either synchronously, or
    * asynchronously. The difference depends simply on the type of method
    * return specified. If the actual type of the return is used in the
    * interface, the method will block until completion as expected. However,
    * if a <a href=http://download.oracle.com/javase/6/docs/api/java/util/concurrent/Future.html>
    * java.util.concurrent.Future</a> is specified, the invocation will
    * return immediately, with the Future object. The future can be
    * periodically checked to see when the invocation is done, and get the
    * result. This is <i>very useful</i> for methods which require lengthy
    * time to complete, so as not to delay other thread processing.
    * @param controllerInterface The class name of the interface to be
    * implemented <i>(e.g. controller.IController.class)</i>
    * @param service The service reference typically obtained from the {@link
    * #testService testService} method.
    * @return An object implementing the service interface provided, yet
    * passing the function invocations directly on to the controller object,
    * or <i>null,</i> if the service does not support a controller
    * @throws Exception If the controller request function failed, for
    * network related reasons
    */
   @SuppressWarnings("unchecked") // sigh...
   protected static final <T> T testController(Class controllerInterface,
      Object service) throws Exception {
      Object controller = Remote.invoke(service, "getController", null);
      return controller == null ? null : (T)TransparentItemProxy.getItem(
         controller, new Class[] { controllerInterface });
   }
   /**
    * This utility function is used to export jar files needed by clients.
    * These jar files contain the class definitions and 3rd party libraries
    * used by proxies and controllers of this server, which would not
    * ordinarily be found in the codebase of the client. It is typically only
    * called once, at the startup of the server. It can be called
    * subsequently, to change the exported codebase on the fly, but that
    * tends to delve into the arena of <i>rocket science.</i> ;)
    * @param jars The collection of jar files needed by a client
    */
   protected static final void export(String... jars) {
      String header = "http://" + Remote.getDefaultClientHost() + ':' +
         codebaseServer.serverPort + '/';
      StringBuilder base = new StringBuilder();
      for (String jar : jars) {
         base.append(header);
         base.append(jar);
         base.append(' ');
      }
      System.setProperty("java.rmi.server.codebase", base.toString());
   }
}
