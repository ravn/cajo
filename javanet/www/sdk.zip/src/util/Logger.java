package util;

import java.rmi.server.RemoteServer;
import java.rmi.RemoteException;
import java.rmi.MarshalledObject;
import java.rmi.server.ServerNotActiveException;
import java.io.ObjectOutputStream;
import gnu.cajo.invoke.*;

/* Copyright 2010 John Catherino
 * The cajo project: https://cajo.dev.java.net
 *
 * Licensed under the Apache Licence, Version 2.0 (the "Licence"); you may
 * not use this file except in compliance with the licence. You may obtain a
 * copy of the licence at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the licence is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * The logger is used to instrument an object for invocation logging
 * purposes. It is intended as a replacement for ordinary or RMI logging, in
 * that this logger is aware of the Invoke package methodology, and can
 * decode it to automatically provide context.  Specifically, it will gather
 * information about the calling client, the method called, the inbound and
 * outbound data. It will also record the approximate time used to service
 * the invocation, and the approximate percentage of free memory available at
 * the completion of the operation.<p>
 * This type of class is very useful for both clients, and services. Clients
 * can wrap remote service references in a logger, to observe their
 * interaction, and the corresponding results. Services can wrap their
 * local references to observe how clients are using them.
 * <p><i><u>NB</u>:</i> Logging may be activated and deactivated
 * administratively as needed on both an instance basis via the field
 * {@link #LOCALOFF LOCALOFF}, and on a class-wide basis via the static field
 * {@link #CLASSOFF CLASSOFF}.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public final class Logger implements Invoke {
   private static final long serialVersionUID = 0L;
   private static final String NULL[] = { "();" } ;
   private static final long maxMem = Runtime.getRuntime().maxMemory();
   private static String server; // name or address & port of this host
   private final String name, clazz; // logged object identification
   private volatile long count; // number of invocations on the logged object
   private ObjectOutputStream oos; // log stream, to file or socket
   /**
    * Every time a method is invoked on the logged object, an Event object
    * will be written to the output stream to describe the invocation. It
    * implements Comparable and Comparator, to allow the collection of events
    * to be sorted with other event objects, by timestamp. The public fields
    * permit straightforward algorithmic analysis of system operation.
    * <p>It contains the following information:<br><ul>
    * <li> The host address of the caller (or localhost w/trace)
    * <li> The host address and port of the server
    * <li> The name of this object
    * <li> The class of this object
    * <li> The method the caller is invoking
    * <li> The arguments the caller is sending
    * <li> The return from the invocation, or the Exception
    * <li> The absolute timestamp of the invocation
    * <li> The run time of the invocation time, in milliseconds
    * <li> The number of times this method has been called
    * <li> The free memory percentage, following the invocation</ul>
    */
   public static final class Event
      implements Comparable, java.util.Comparator, java.io.Serializable {
      private static final long serialVersionUID = 0L;
      private Event(Logger logger, String caller, String method,
         String args[], String result, long time, long busy, long count,
         int freemem) {
         this.name    = logger.name;
         this.clazz   = logger.clazz;
         this.caller  = caller;
         this.method  = method;
         this.args    = args;
         this.result  = result;
         this.time    = time;
         this.busy    = busy;
         this.count   = count;
         this.freemem = freemem;
      }
      /**
       * The internal machine name or address of the JVM serving the object.
       */
      public final String server = Logger.server;
      /**
       * The instance name of the logged object being invoked.
       */
      public final String name;
      /**
       * The class name of the logged object being invoked.
       */
      public final String clazz;
      /**
       * The machine name or IP address of the calling JVM, or localhost.
       */
      public final String caller;
      /**
       * The name of the method of the logged object being invoked.
       */
      public final String method;
      /**
       * The names of the arguments provided to the invocation, or "();" if
       * none.
       */
      public final String args[];
      /**
       * The name of the result object of the invocation. It will be "null",
       * if the method either returns null, or is of return type void.
       */
      public final String result;
      /**
       * The percentage of free memory remaining following the method
       * invocation. Its range is from 0 to 100, in per centum.
       */
      public final int freemem;
      /**
       * The absolute timestamp of the invocation, this can be used to
       * compare with the timing of invocations on other objects/machines.
       */
      public final long time;
      /**
       * The time required to complete the invocation, in milliseconds.
       */
      public final long busy;
      /**
       * The number of times the object has been invoked, through this logger
       * instance.
       */
      public final long count;
      /**
       * This method can allow object events to be sorted by absolute
       * timestamp, to put the events into chronological order.
       * @param o1 An object <i>(presumably an Event)</i> to be compared for
       * timeliness
       * @param o2 An object <i>(presumably an Event)</i> to be compared for
       * timeliness
       * @return a negative value, if the first event occurred <i>before</i>
       * the second event, zero if they happened at the <i>same</i> time, and a
       * positive value, if the first event occurred <i>after</i> the second
       */
      public int compare(Object o1, Object o2) {
         return (int)(((Event)o1).time - ((Event)o2).time);
      }
      /**
       * This method can allow streams of object events to be joined and
       * sorted by absolute timestamp, putting the events into chronological
       * order.
       * @param o The object <i>(presumably an Event)</i> to be compared for
       * timeliness with this instance
       * @return a negative value, if the event occurred <i>before</i> this
       * event, zero if it happened at the <i>same</i> time, and a positive
       * value, if the event occurred <i>after</i> this one
       */
      public int compareTo(Object o) { return (int)(((Event)o).time - time); }
      /**
       * This method will generate a pretty text representation of the contents
       * of the event object instance.
       * @return The formatted string containing all of the event data, for
       * easy viewing
       */
      public String toString() {
         StringBuilder sb = new StringBuilder();
         sb.append("\nserver = "); sb.append(server);
         sb.append("\nobject = "); sb.append(name);
         sb.append("\nclass  = "); sb.append(clazz);
         sb.append("\ncaller = "); sb.append(caller);
         sb.append("\nmethod = "); sb.append(method);
         sb.append("\nargs   = "); sb.append(args[0]);
         for (int i = 1; i < args.length; i++)
            { sb.append("\n\t ");  sb.append(args[i]); }
         sb.append("\nresult = "); sb.append(result);
         sb.append("\ntime   = "); sb.append(time);
         sb.append("\nbusy   = "); sb.append(busy); sb.append("ms");
         sb.append("\ncount  = "); sb.append(count);
         sb.append("\nmemory = "); sb.append(freemem); sb.append("% free\n");
         return sb.toString();
      }
   }
   /**
    * This flag, if true, will force <i>all</i> loggers to write to their
    * output streams. Normally this will provide much more detail than is
    * needed in normal operation. It is used primarily to diagnose a problem
    * with system operation.
    */
   public static boolean DEBUG;
   /**
    * This flag can be used to selectively enable and disable logging
    * on a class-wide level. By default it is set to false, when true, no
    * output to <i>any logstream for all loggers from that class loader</i>
    * will take place. It is subjugate to the DEBUG flag.
    */
   public static boolean CLASSOFF;
   /**
    * This flag can be used to selectively enable and disable logging on an
    * instance level. By default it is set to false, when true, no output to
    * the logstream will take place. It is subjugate to the CLASSOFF flag.
    */
   public boolean LOCALOFF;
   /**
    * The object being logged. It is declared as public to allow use of both
    * the reference of the logger, and its wrapped object, from a single
    * reference. The object itself may either be local, remote, or a dynamic
    * proxy, to either a local or remote object.
    */
   public final Object object;
   /**
    * The constructor creates the logger object, to instrument the target
    * object's use. It will send Event objects to the stream for each
    * method invocation on the logged object.
    * <br><i><u>NB</u>:</i> Multiple loggers can use the <i>same</i> stream.
    * @param object The object to receive the client invocation, it can be
    * local, remote, or a dymic proxy to either a local or remote object
    * @param oos The output stream to write the invocation event objects,
    * if this argument is null, the events will be written to System.out
    * <br><i><u>NB</u>:</i> it is <i>highly</i> recommended to build oos
    * atop a BufferedOutputStream, and if a lot of invocations are being
    * logged, possibly a ZippedOutputStream as well.
    */
   public Logger(Object object, ObjectOutputStream oos) {
      this.object = object;
      this.oos    = oos;
      this.name   = object.toString();
      this.clazz  = object.getClass().getName() + '@' +
         Integer.toHexString(object.hashCode());
   }
   /**
    * This method is used to periodically change out the log stream object.
    * Normally this is done for long running objects. As mentioned in the
    * constructor docs, multiple loggers can use the same stream.
    * @param oos The output stream to write the invocation event objects
    * <br><i><u>NB</u>:</i> it is <i>highly</i> recommended to build oos
    * atop a BufferedOutputStream, and if a lot of invocations are being
    * logged, possibly a ZippedOutputStream as well.
    * @return The previous log stream, typically for flushing and closing,
    * it can return null however, if it was previously logging to the
    * console
    */
   public ObjectOutputStream changeLog(ObjectOutputStream oos) {
      try     { return this.oos; }
      finally { this.oos = oos;  }
   }
   /**
    * This method logs the incoming calls, passing the caller's data to the
    * internal object reference.
    * @param method The internal object's public method being called
    * @param  args The arguments to pass to the internal object's method
    * @return The sychronous data, if any, resulting from the invocation
    * @throws RemoteException For a network related failure
    * @throws NoSuchMethodException If the method/agruments signature cannot
    * be matched to the internal object's public method interface
    * @throws Exception If the internal object's method rejects the
    * invocation for application specific reasons
    */
   public Object invoke(String method, Object args) throws Exception {
      if (!DEBUG && (CLASSOFF || LOCALOFF))
         return Remote.invoke(object, method, args);
      long time = System.currentTimeMillis();
      Object result = null;
      try { return result = Remote.invoke(object, method, args); }
      catch(Exception x) { // an exception is a result for the logger
         result = x;
         throw x;
      } finally {
         long busy = System.currentTimeMillis() - time;
         String caller;
         try { caller = RemoteServer.getClientHost(); }
         catch(ServerNotActiveException x) { caller = "localhost"; }
         if (args instanceof MarshalledObject)
            args = ((MarshalledObject)args).get();
         if (args instanceof Object[]) {
            String temp[] = new String[((Object[])args).length];
            for (int i = 0; i < temp.length; i++)
               temp[i] = ((Object[])args)[i].toString();
            args = temp;
         } else args = args != null ? new String[] { args.toString() } : NULL;
         result = result instanceof MarshalledObject ? 
            ((MarshalledObject)result).get().toString() :
            result != null ? result.toString() : "null";
         if (server == null) server = Remote.getDefaultServerHost() + ':' +
            Remote.getDefaultServerPort();
         Event event = new Event(this, caller, method, (String[])args,
            (String)result, time, busy, ++count,
            100 - (int)(Runtime.getRuntime().freeMemory() * 100 / maxMem));
         if (oos != null) try { oos.writeObject(event); }
            catch(java.io.IOException x) { oos = null; }
         else System.out.print(event);
      }
   }
}
