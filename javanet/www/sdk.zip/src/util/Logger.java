package util;

import gnu.cajo.invoke.*;
import java.rmi.server.RemoteServer;
import java.rmi.RemoteException;
import java.rmi.MarshalledObject;
import java.rmi.server.ServerNotActiveException;
import java.io.ObjectOutputStream;

/*
 * Object Invocation Logger
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino
 */

/**
 * This class is used to instrument an object for invocation logging
 * purposes. It is intended as a replacement for standard RMI logging, in that
 * this logger is aware of the Invoke package methodology, and can decode it
 * properly.  Specifically, it will gather information about the calling
 * client, the method called, the inbound and outbound data. It will also
 * record the approximate time used to service the invocation, and the
 * approximate percentage of free memory available at the completion of the
 * operation.
 * <p>This type of class is very useful for both clients, and servers.
 * Clients can wrap remote server object references in a logger, to observe
 * their interaction, and the corresponding results. Servers can wrap their
 * local service object references before remoting, to observe how clients
 * are using their objects.<p>
 * <i><u>NB</u>:</i> logging is not free in terms of runtime performance. It
 * is recommended to use only when necessary, and is <i>not</i> recommended
 * for methods that will be called very frequently.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public class Logger implements Invoke {
   private static String inip; // name or address & port of this host
   private long count; // total number of invocations on the logged object
   private int hash; // wrapped item's hashcode
   /**
    * This flag can be used to selectively enable and disable logging
    * on a class-wide level. By default it is set to false, when true, no
    * output to any logstream will take place for all loggers loaded by a
    * given class loader.
    */
   public static boolean CLASSOFF;
   /**
    * This flag can be used to selectively enable and disable logging on an
    * instance level. By default it is set to false, when true, no output to
    * the local logstream will take place.
    */
   public boolean LOCALOFF;
   /**
    * The object being logged. It is declared as public to allow use of both
    * the reference of the logger, and its wrapped object, from a single
    * instance.
    */
   public final Object item;
   /**
    * This is the optional stream that event objects can be written to. It
    * could be to a file on disc, or even being over a network socket. This
    * field would normally only be changed to start a new log file at runtime.
    * Also, though uncommon, the same stream <i>could</i> be used to log
    * multiple objects.
    */
   public ObjectOutputStream oos;
   /**
    * Every time a method is invoked on the logged object, an Event object
    * will be written to the output stream to describe the invocation. It
    * implements Comparable and Comparator, to allow the collection of events
    * to be sorted with other object event objects, by timestamp. The public
    * fields permit straightforward algorithmic analysis of system operation.
    */
   public static final class Event implements Comparable,
      java.util.Comparator,  java.io.Serializable {
      private static final long serialVersionUID = 0L;
      private Event(String caller, String server, String object, int hash,
         String method, String args[], String result[], long time, long busy,
         long count, int freemem) {
         this.caller  = caller;
         this.server  = server;
         this.object  = object;
         this.hash    = hash;
         this.method  = method;
         this.args    = args;
         this.result  = result;
         this.time    = time;
         this.busy    = busy;
         this.count   = count;
         this.freemem = freemem;
      }
      /**
       * The machine name or IP address of the calling JVM, or localhost.
       */
      public final String caller;
      /**
       * The internal machine name or address of the JVM serving the object.
       */
      public final String server;
      /**
       * The name of the logged object being invoked.
       */
      public final String object;
      /**
       * The name of the method of the logged object being invoked.
       */
      public final String method;
      /**
       * The arguments provided to the invocation. It will be null, if no
       * arguments are provided.
       */
      public final String args[];
      /**
       * The result object(s) of the invocation. It will be null, if the
       * method either returns null, or is of return type void.
       */
      public final String result[];
      /**
       * The hash code of the instance of the object being logged, used to
       * distinguish it from other logged object instances of the same type.
       */
      public final int hash;
      /**
       * The approximate percentage of free memory remaining following the
       * method invocation. Its range is from 0 to 100, in per centum.
       */
      public final int freemem;
      /**
       * The absolute timestamp of the invocation, this can be used to
       * compare with the timing of invocations on other objects/machines.
       */
      public final long time;
      /**
       * The time required to complete the invocation, in milliseconds.
       */
      public final long busy;
      /**
       * The number of times the object has been invoked, through this logger
       * instance.
       */
      public final long count;
      /**
       * This method can allow object events to be sorted by absolute
       * timestamp, to put the events into chronological order.
       * @param o1 An object <i>(presumably an Event)</i> to be compared for
       * timeliness
       * @param o2 An object <i>(presumably an Event)</i> to be compared for
       * timeliness
       * @return a negative value, if the first event occurred <i>before</i>
       * the second event, zero if they happened at the <i>same</i> time, and a
       * positive value, if the first event occurred <i>after</i> this second
       */
      public int compare(Object o1, Object o2) {
         return (int)(((Event)o1).time - ((Event)o2).time);
      }
      /**
       * This method can allow streams of object events to be joined and
       * sorted by absolute timestamp, putting the events into chronological
       * order.
       * @param o The object <i>(presumably an Event)</i> to be compared for
       * timeliness with this instance
       * @return a negative value, if the event occurred <i>before</i> this
       * event, zero if it happened at the <i>same</i> time, and a positive
       * value, if the event occurred <i>after</i> this one
       */
      public int compareTo(Object o) { return (int)(((Event)o).time - time); }
      /**
       * This method will generate a <i>pretty</i> text representation of
       * the contents of the event object instance.
       * @return The formatted string containing all of the event data, for
       * easy viewing.
       */
      public String toString() {
         StringBuffer sb = new StringBuffer();
         sb.append("\ncaller = "); sb.append(caller);
         sb.append("\nserver = "); sb.append(server);
         sb.append("\nobject = "); sb.append(object); sb.append('@');
         sb.append(Integer.toHexString(hash));
         sb.append("\nmethod = "); sb.append(method);
         sb.append("\nargs   = ");
         if (args != null) {
            sb.append(args[0]);
            for (int i = 1; i < args.length; i++) {
               sb.append("\n\t ");
               sb.append(args[i]);
            }
         } else sb.append("();");
         sb.append("\nresult = ");
         if (result != null) {
            sb.append(result[0]);
            for (int i = 1; i < result.length; i++) {
               sb.append("\n\t ");
               sb.append(result[i]);
            }
         } else sb.append("null");
         sb.append("\ntime   = "); sb.append(time);
         sb.append("\nbusy   = "); sb.append(busy); sb.append("ms");
         sb.append("\ncount  = "); sb.append(count);
         sb.append("\nmemory = "); sb.append(freemem); sb.append("%\n");
         return sb.toString();
      }
   }
   /**
    * The constructor creates the logger object, to instrument the target
    * object's use.
    * @param item The object to receive the client invocation, for obvious
    * reasons, this argument may <i><u>not</u></i> be null.
    * @param oos The output stream to write the invocation event objects,
    * if this argument is null, the events will be written to System.out,
    * if the logging is expected to be extensive, it is recommended to
    * build the output stream on top of a zipped stream, whether to a file,
    * or a network socket.
    */
   public Logger(Object item, ObjectOutputStream oos) {
      this.item = item;
      this.hash = item.hashCode();
      this.oos  = oos;
   }
   /**
    * This method logs the incoming calls, passing the caller's data to the
    * internal item. It records the following information:<p><ul>
    * <li> The host address of the caller (or localhost w/trace)
    * <li> The host address of the server
    * <li> The name of this object
    * <li> The object's hashcode
    * <li> The method the caller is invoking
    * <li> The data the caller is sending
    * <li> The data resulting from the invocation, or the Exception
    * <li> The absolute timestamp of the invocation
    * <li> The run time of the invocation time, in milliseconds
    * <li> The number of times this method has been called
    * <li> The free memory percentage, following the invocation</ul><p>
    * <i><u>NB</u>:</i> Logging may be activated and deactivated
    * administratively as needed on both an instance basis via the field
    * {@link #LOCALOFF LOCALOFF}, and on a class-wide basis via the static field
    * {@link #CLASSOFF CLASSOFF}.
    * @param method The internal object's public method being called.
    * @param  args The arguments to pass to the internal object's method.
    * @return The sychronous data, if any, resulting from the invocation.
    * @throws RemoteException For a network related failure.
    * @throws NoSuchMethodException If the method/agruments signature cannot
    * be matched to the internal object's public method interface.
    * @throws Exception If the internal object's method rejects the
    * invocation for application specific reasons.
    */
   public Object invoke(String method, Object args) throws Exception {
      if (CLASSOFF || LOCALOFF) return Remote.invoke(item, method, args);
      long time = System.currentTimeMillis();
      Object result = null;
      try { return result = Remote.invoke(item, method, args); }
      catch(Exception x) { // an exception is a result for the logger
         result = x;
         throw x;
      } finally {
         long run = System.currentTimeMillis() - time;
         String caller;
         try { caller = RemoteServer.getClientHost(); }
         catch(ServerNotActiveException x) { caller = "localhost"; }
         if (args instanceof MarshalledObject)
            args = ((MarshalledObject)args).get();
         if (args instanceof Object[]) {
            String temp[] = new String[((Object[])args).length];
            for(int i = 0; i < temp.length; i++)
               temp[i] = ((Object[])args)[i].toString();
            args = temp;
         } else args = args == null ? null : new String[] { args.toString() };
         if (result instanceof MarshalledObject)
            result = ((MarshalledObject)result).get();
         if (result instanceof Object[]) {
            String temp[] = new String[((Object[])result).length];
            for(int i = 0; i < temp.length; i++)
               temp[i] = ((Object[])result)[i].toString();
            result = temp;
         } else result = result == null ?
            null : new String[] { result.toString() };
         Runtime rt = Runtime.getRuntime();
         if (inip == null) inip = Remote.getDefaultServerHost() + ':' +
            Remote.getDefaultServerPort();
         Event event = new Event(caller, inip, item.getClass().getName(),
            hash, method, (String[])args, (String[])result, time,
            run, ++count, (int)((rt.freeMemory() * 100) / rt.totalMemory()));
         if (oos != null) try { oos.writeObject(event); }
         catch(Exception x) { oos = null; }
         if (oos == null) System.out.print(event);
      }
   }
}
