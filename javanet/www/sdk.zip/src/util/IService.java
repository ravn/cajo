package util;

/*
 * The base interface for a service of a cajo grail server.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This interface is released into the public domain.
 * Written by John Catherino
 */

/**
 * This interface defines the canonical functions expected to be furnished
 * by <i>all</i> <a href=https://cajo.dev.java.net>cajo</a> services. It is
 * normally subclassed, to define application specific service function
 * definitions.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public interface IService {
   /**
    * This method is called by remote clients, to get a standardised html
    * encoded destription of the service's functions. The format is
    * invariant, to allow automated parsing, if desired.
    * @return A detailed description of the functionality of the service
    * @throws java.rmi.RemoteException For network related failure or
    * configuration issues
    */
   String getDescription() throws java.rmi.RemoteException;
   /**
    * This method is called by remote clients to request the service's
    * optionally implemented controller, and its potentially its optional GUI
    * view. Requesting a service's controller is recommended over direct
    * invocation on the service reference for four fundamental reasons:<br><ul>
    * <li>To allow the service to offload processing
    * <li>To provide higher performance to the receiving service
    * <li>To furnish additional retry/rollback functionality, as necessary
    * <li>To retain receiver state information for the sending service, as
    * necessary</ul>
    * <i><u>NB</u>:</i> Ability to receive remote controllers is <i>disabled</i>
    * by default, for security reasons; as malicious controllers could easily
    * hinder, or crash the server. Accepting controllers should only be done
    * in a trusted environment. To enable the acceptance of controllers
    * <i>(and proxies)</i> call the static <tt>ItemServer.acceptProxies();</tt>
    * method. (this would normally be done in the server's Main class)<p>
    * *An important way to mitigate this risk, is to have the class
    * definitions needed by the client proxy already part of the server's
    * local codebase. The service will then load its own version, rather than
    * dynamically, via the mobile code mechanism. This would <u>not</u>
    * require calling the <tt>ItemServer.acceptProxies()</tt> method.
    * @return Object A local reference to a service's controller object
    * @throws java.rmi.RemoteException For network related failure or
    * configuration issues
    */
   Object getController() throws java.rmi.RemoteException;
   /**
    * This method allows remote clients to install local proxies to interact
    * with the service resource locally.<p>
    * The arriving client proxy object will have its <tt>init</tt> method
    * called with a local reference to the receiving service, on with to
    * operate. It could be considered the <i>logical inverse</i> of
    * requesting a service's controller. The proxy can use the service's
    * static Cajo object, to request other remote server resources, or even
    * to export itself. It is used for similar reasons as controllers; to
    * reduce network traffic if a lot of interaction is required with the
    * service, which would also improve performance.<p>
    * This technique is often used to support the paradigm: <i>bring the
    * code to the data.</i> Often the size of the code to manipulate large
    * data sets is <i>much</i> smaller; this can be used to greatly reduce
    * network traffic of sending large data blocks, and improve system
    * efficiency as well.<p>
    * <i><u>NB</u>:</i> Ability to receive remote proxies is <i>disabled</i>
    * by default, for security reasons; as malicious proxies could easily
    * hinder, or crash the server. Accepting proxies should only
    * be done in a trusted environment. To enable the acceptance of proxies
    * <i>(and controllers)</i> call the static <tt>ItemServer.acceptProxies();</tt>
    * method. (this would normally be done in the server's Main class)<p>
    * *An important way to mitigate this risk, is to have the class
    * definitions needed by the client proxy already part of the server's
    * local codebase. The service will then load its own version, rather than
    * dynamically, via the mobile code mechanism. This would <u>not</u>
    * require calling the <tt>ItemServer.acceptProxies()</tt> method.
    * @param proxy The client's object, which it wants to run within the
    * service JVM, presumably to improve performance by reducing network
    * traffic, it will be extracted from the MarshalledObject, then have its
    * <tt>init</tt> method called, passing in a local reference to the
    * service object
    * @return A remote reference to the installed proxy, on which the client
    * may communicate with it, in whatever manner it wishes, if needed, it
    * cal also be passed between JVMs
    * @throws NoSuchMethodException If the proxy does not implement a public
    * init method to accept proxy objects
    * @throws java.rmi.RemoteException For network related failure or
    * configuration issues
    */
   Object acceptProxy(Object proxy) throws Exception;
}
