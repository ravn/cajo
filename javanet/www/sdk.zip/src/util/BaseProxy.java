package util;

/*
 * A base proxy class for a cajo grail server.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino
 */

/**
 * The proxy is a piece of executable code, sent from one service to run
 * locally at another service. It is the logical converse of the controller
 * object. It is normally used either when a client has to interact
 * frequently with a service, so as to minimise network traffic; or if the
 * target service operates operates on large data sets, to prevent having to
 * send the data over the network.<br>
 * <i><u>NB</u>:</i> not all service object accept proxies, as a malicious
 * proxy could crash the service JVM e.g. by excessive memory allocation.
 * They are primarily accepted in well known domains, where the proxies are
 * trusted.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public class BaseProxy {
   /**
    * The reference to the remote service from which the proxy was sent. It
    * is used to make asynchronous callbacks to the sending service.
    */
   protected final Object homeService;
   /**
    * The local reference to the remote service to which the proxy was sent.
    * It is used to autonomously interact with the target service.
    */
   protected Object localService;
   /**
    * The constructor simply assigns the remote service reference.
    * @param service A remote reference to the sending service, over
    * which the proxy may asynchronously communicate with it
    */
   protected BaseProxy(Object homeService) { this.homeService = homeService; }
   /**
    * This method allows subclasses of BaseProxy to dynamically
    * cast the local service reference into an interface of its choice.
    * @param proxyInterface The class name of the interface to be
    * emulated <i>(e.g. somepkg.ThisInterface.class)</i>
    * @return An object implementing the interface provided
    */
   @SuppressWarnings("unchecked") // sigh...
   protected final <T> T proxy(Class proxyInterface) {
      return (T)gnu.cajo.utils.extra.TransparentItemProxy.
         getItem(localService, new Class[] { proxyInterface });
   }
   /**
    * This method is invoked only once, by the target service upon arrival.
    * After initialisation, the proxy can use the local service's static
    * Service.cajo object, to lookup and interact with any other services it
    * may need. If this method is overridden, be sure to call
    * super.init(service);.
    * @param service A local reference to the target service object
    */
   public void init(Object localService) { this.localService = localService; }
}
