package util;

import java.awt.event.WindowListener;
import javax.swing.JFrame;

/*
 * A base controller class for a cajo grail server.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino
 */

/**
 * The controller is the smart go-between of a client, or its own graphical
 * view, and its remote service object. It is expected to offload server
 * workload and local storage related to the support of the client. Once
 * obtained by a client, the controller reference can be freely passed
 * around to other JVMs.<br>
 * <i><u>NB</u>:</i> Just as with service objects, a controller instance must
 * assume that it will be used by multiple threads, concurrently, therefore
 * protection of non-threadsafe regions is essential.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public abstract class AbstractController extends AbstractObject
   implements IController {
   /**
    * This string provides a standard description for throwing no checked
    * exceptions. This is only possible for controllers, where a function
    * executes entirely locally, and does not throw any exceptions of its
    * own. It is provided here and recommended, for convenient reuse.
    */
   protected static final String[] NOEXCEPTION = {
      "<i>none</i>", "This function throws no checked exceptions."
   };
   /**
    * This is a reference to the remote service instance. It can be used
    * directly by <a href=http://weblogs.java.net/blog/cajo/archive/2007/09/simple_interjvm.html>
    * advanced cajo users</a>, but is not accessed normally. The local {@link
    * #proxy proxy} method is typically used, to create dynamic proxies to the
    * remote reference, to use it syntactically, as if the service itself was
    * local.
    */
   protected final Object service;
   /*
    * This is the reference to the the view object the component will
    * instantiate, listen to, and modify at runtime.
    */
   protected transient AbstractView view;
   /**
    * A reference to the local server's cajo reference, with which the
    * controller may look up other services, or even export itself.
    */
   protected transient gnu.cajo.Cajo cajo;
   /**
    * The constructor simply assigns the remote service reference and defines
    * the canonical controller functions.
    * @param service A remote reference to the service, over which the
    * controller may asynchronously communicate with it
    */
   protected AbstractController(Object service) {
      this.service = service;
      descriptors.add(new Descriptor("getView",
         "This <i>canonical*</i> function is normally called by a " +
         "graphical client, to get the view component associated with " +
         "this controller,  to display in its own frame.<br>*canonical " +
         "meaning it is <i>expected</i> to be implemented by <u>all</u> " +
         "services",
         null, // method accepts no arguments
         new String[] { // return
            "util.AbstractView",
            "A graphical component which can then be consolidated into " +
            "any container for viewing. <i><u>NB</u>:</i> The method " +
            "<i>may</i> return null, if the controller has no view."
         }, new String[][] { // exceptions
            new String[] {
               "java.io.IOException",
               "If the needed UI resource objects cannot be found"
            },
         }
      ));
   }
   /**
    * This method allows subclasses of AbstractController to dynamically cast
    * its remote server reference into a local interface of its choice.
    * @param serviceInterface The class of the interface to be implemented
    * <i>(e.g. somepkg.SomeInterface.class)</i>
    * @return An object implementing the interface provided, yet passing
    * the function invocations directly onto the service object.
    */
   @SuppressWarnings("unchecked") // sigh...
   protected final <T> T proxy(Class serviceInterface) {
      return (T)gnu.cajo.utils.extra.TransparentItemProxy.
         getItem(service, new Class[] { serviceInterface });
   }
   /**
    * This method provides a means to identify this controller.
    * @return A identifier <i>(not description)</i> of the controller
    */
   public String toString() { return "AbstractController"; }
   public void init(gnu.cajo.Cajo cajo) { this.cajo = cajo; }
}
