package util;

import java.awt.event.WindowListener;
import javax.swing.JFrame;

/* Copyright 2010 John Catherino
 * The cajo project: https://cajo.dev.java.net
 *
 * Licensed under the Apache Licence, Version 2.0 (the "Licence"); you may
 * not use this file except in compliance with the licence. You may obtain a
 * copy of the licence at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the licence is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * The controller is the smart go-between for a client object, or its own
 * graphical {@link AbstractView view}, and its remote {@link AbstractService
 * service} object. It is used primarily to offload server workload and local
 * storage related to the support of the client. Once obtained it can be
 * passed freely between clients, <i>however,</i> it must be passed wrapped
 * in a <tt>java.rmi.MarshalledObject.</tt> The receiver would then call its
 * <tt>get()</tt> method to extract the controller.<br>
 * <i><u>NB</u>:</i> Just as with service objects, a controller instance must
 * assume that it will be used by multiple threads, <i>concurrently,</i>
 * therefore synchronisation of non-threadsafe code regions is essential.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public abstract class AbstractController extends AbstractObject
   implements IController {
   /**
    * This string provides a standard description for throwing no checked
    * exceptions. This is only possible for controllers, where a function
    * executes entirely locally, and does not throw any exceptions of its
    * own. It is provided here and recommended, for convenient reuse.
    */
   protected static final String[] NOEXCEPTION = {
      "<i>none</i>", "This function throws no checked exceptions."
   };
   /**
    * This is a reference to the remote service instance. It can be used
    * directly by <a href=http://weblogs.java.net/blog/cajo/archive/2007/09/simple_interjvm.html>
    * advanced cajo users</a>, but is not accessed normally. The local {@link
    * #proxy proxy method} is typically used, to create dynamic proxies to the
    * remote reference, to use it syntactically, as if the service itself was
    * local.
    */
   protected final Object service;
   /*
    * This is the reference to the the view object the component will
    * instantiate, listen to, and modify at runtime.
    */
   protected transient AbstractView view;
   /**
    * A reference to the local server's cajo reference, with which the
    * controller may look up other services, or even export itself.
    */
   protected transient gnu.cajo.Cajo cajo;
   /**
    * The constructor simply assigns the remote service reference and defines
    * the canonical controller functions.
    * @param service A remote reference to the service, over which the
    * controller may asynchronously communicate with it
    */
   protected AbstractController(Object service) {
      this.service = service;
      descriptors.add(new Descriptor("getView",
         "This <i>canonical*</i> function is normally called by a " +
         "graphical client, to get the view component associated with " +
         "this controller,  to display in its own frame.<br>*canonical " +
         "meaning it is <i>expected</i> to be implemented by <u>all</u> " +
         "services",
         null, // method accepts no arguments
         new String[] { // return
            "util.AbstractView",
            "A graphical component which can then be consolidated into " +
            "any container for viewing. <i><u>NB</u>:</i> The method " +
            "<i>may</i> return null, if the controller has no view."
         }, new String[][] { // exceptions
            {
               "java.io.IOException",
               "If the needed UI resource objects cannot be found"
            },
         }
      ));
   }
   /**
    * This method allows subclasses of AbstractController to dynamically cast
    * its, or any other, remote server reference, into a local interface of
    * its choice. The local interface can specify as much, or as little, of
    * the service's public methods as needed.
    * <br><i><u>NB</u>:</i> methods can be invoked either synchronously, or
    * asynchronously. The difference depends simply on the type of method
    * return specified. If the actual type of the return is used in the
    * interface, the method will block until completion as expected. However,
    * if a <a href=http://download.oracle.com/javase/6/docs/api/java/util/concurrent/Future.html>
    * java.util.concurrent.Future</a> is specified, the invocation will
    * return immediately, with the Future object. The future can be
    * periodically checked to see when the invocation is done, and get the
    * result. This is <i>very useful</i> for methods which require lengthy
    * time to complete, so as not to delay other thread processing.
    * @param serviceInterface The class of the interface to be implemented
    * <i>(e.g. somepkg.SomeInterface.class)</i>
    * @return An object implementing the interface provided, yet passing
    * the function invocations directly onto the service object.
    * <br><i><u>NB</u>:</i> If any of the arguments passed onto an invocation
    * are not serialisable, or the result is not; those objects will be
    * transparently replaced with dynamic proxies, implementing all of the
    * remote object's interfaces. Hence the practice of using interfaces,
    * rather than objects, in method signatures is recommended. A local
    * dynamic proxy can be created with a local interface, on a dynamic
    * proxy of a remote object.
    */
   @SuppressWarnings("unchecked") // sigh...
   protected final <T> T proxy(Class serviceInterface) {
      return (T)gnu.cajo.utils.extra.TransparentItemProxy.
         getItem(service, new Class[] { serviceInterface });
   }
   /**
    * This method provides a means to identify this controller.
    * @return An identifier <i>(not a description)</i> of the controller
    */
   public String toString() { return "AbstractController"; }
   public void init(gnu.cajo.Cajo cajo) { this.cajo = cajo; }
}
