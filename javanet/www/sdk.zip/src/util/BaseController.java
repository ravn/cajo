package util;

import gnu.cajo.utils.extra.TransparentItemProxy;
import javax.swing.JFrame;
import javax.swing.JComponent;
import java.awt.event.WindowListener;

/*
 * A base controller class for a cajo grail server.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino
 */

/**
 * The controller is the smart go-between of a client, or its own graphical
 * view, and its remote service object. It is expected to offload server
 * workload and local storage related to the support of the client.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public abstract class BaseController
   implements java.io.Serializable, IBaseController {
   private static final long serialVersionUID = 0L;
   /**
    * This is a reference to the remote service instance. It can be used
    * by <a href=http://weblogs.java.net/blog/cajo/archive/2007/09/simple_interjvm.html>
    * advanced cajo users</a>, but is not accessed normally. The local {@link
    * #proxy proxy} method is typically used, to create dynamic proxies to the
    * remote reference, to use it syntactically, as if the service itself was
    * local.
    */
   protected Object service;
   /**
    * The constructor performs no functions, however Controller subclasses
    * need to have no-arg constructors, if they are to be used via the
    * {@link util.ProxyLoader ProxyLoader} mechanism.
    */
   protected BaseController() {}
   /**
    * This medhod provides a simple unit test of the interaction between
    * the designated view, and a test object. It will instantiate its view
    * object, and place it in a JFrame.
    * @param service An object which will be representing the remote service
    * for the purposes of testing
    * @throws Exception if the view could not be created, typically due to
    * missing resource issues
    */
   protected final void test(Object service) throws Exception { // unit test
      this.service = service;
      JFrame frame = new JFrame("Unit Test");
      JComponent component = getView();
      if (component instanceof WindowListener)
         frame.addWindowListener((WindowListener)component);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.getContentPane().add(component);
      frame.pack();
      frame.setVisible(true);
   }
   /**
    * This method allows subclasses of BaseController to dynamically
    * cast a remote service reference into an interface of its choice.
    * @param proxyInterface The class name of the interface to be
    * emulated <i>(e.g. somepkg.ThisInterface.class)</i>
    * @return An object implementing the interface provided, yet passing
    * the function invocations directly on to the service object.<p>
    * <i><u>NB</u>:</i> this object is serialisable, and may be passed
    * between JVMs. However, unlike passing the MarshalledObject from the
    * service <tt>getController</tt>, receivers of this object would be
    * communicating with the service through the controller reference located
    * in this object. <i>(an interesting and important fact)</i>
    */
   @SuppressWarnings("unchecked") // sigh...
   protected final <T> T proxy(Class proxyInterface) {
      return (T)TransparentItemProxy.
         getItem(service, new Class[] { proxyInterface });
   }
   /**
    * This method is called once, by the BaseService, to assign the
    * controller's remote reference to it. It cannot be called after that.
    * @param service The reference to the remote <a href=https://cajo.dev.java.net>
    * cajo</a> service object
    * @throws RuntimeException If the function is called outside the service
    */
   public void setService(Object service) {
      if (this.service != null)
         throw new RuntimeException("proxy already initialised");
      this.service = service;
   }
}
