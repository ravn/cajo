package util;

/*
 * A class to transport proxies and controllers between cajo services.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino
 */

/**
 * This <i>internal use only</i> helper class is used by service classes to
 * send and receive controllers and proxies.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
final class ObjectSender implements gnu.cajo.invoke.Invoke {
   private static final long serialVersionUID = 0L;
   private final java.rmi.MarshalledObject mob;
   private transient Object target;
   /**
    * The constructor merely saves the reference to the supplied object for
    * use at the target JVM.
    * @param pl The ProxyLoader reference to the proxy or controller
    * @throws IOException If the provided object is not serialisable
    */
   ObjectSender(ProxyLoader pl) throws java.io.IOException {
      mob = new java.rmi.MarshalledObject(pl);
   }
   /**
    * This method will instantiate the wrapped object on its first call, and
    * pass all invocations onto it.
    * @param  method The method to invoke on the internal object
    * @param args The arguments to provide to the method for its invocation
    * @return The sychronous data, if any, resulting from the invocation
    * @throws java.rmi.RemoteException For network communication related
    * reasons
    * @throws NoSuchMethodException If no matching method can be found
    * @throws Exception If the internal object rejects the request, for any
    * application specific reason
    */
   public Object invoke(String method, Object args) throws Exception {
      if (target == null) target = mob.get();
      return gnu.cajo.invoke.Remote.invoke(target, method, args);
   }
}
