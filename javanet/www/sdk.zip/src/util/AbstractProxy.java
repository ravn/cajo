package util;

/* Copyright 2010 John Catherino
 * The cajo project: https://cajo.dev.java.net
 *
 * Licensed under the Apache Licence, Version 2.0 (the "Licence"); you may
 * not use this file except in compliance with the licence. You may obtain a
 * copy of the licence at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the licence is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * The proxy is a piece of executable code, sent from one {@link
 * AbstractService service} to run locally at another. It is the logical
 * converse of the controller object. It is normally used either when a
 * client has to interact frequently with a service, so as to minimise
 * network traffic; or if the receiving service operates operates on large
 * data sets, to prevent having to send large amounts of data over the
 * network.<br>
 * <i><u>NB</u>:</i> Not all service objects accept proxies, as a malicious
 * proxy could crash the service JVM e.g. by excessive memory allocation.
 * They are primarily accepted in well known domains, where the proxies are
 * trusted, or where the proxy class definitions are already in the classpath
 * of the server.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public abstract class AbstractProxy implements IProxy {
   /**
    * The remote reference to the sending service it is used to make
    * asynchronous callbacks.
    */
   protected final Object homeService;
   /**
    * The local reference to the receiving service it is used to
    * autonomously interact with it.
    */
   protected transient Object localService;
   /**
    * A reference to the receiving server's cajo reference, with which the
    * proxy may look up other services, or even export itself.
    */
   protected transient gnu.cajo.Cajo cajo;
   /**
    * The constructor simply assigns the remote service reference.
    * @param homeService A remote reference to the sending service, over
    * which the proxy may asynchronously communicate with it
    */
   protected AbstractProxy(Object homeService) {
      this.homeService = homeService;
   }
   /**
    * This method allows subclasses of AbstractProxy to dynamically cast a
    * remote or local service reference, or obtained controller, into an
    * interface of its choice. The interface provided can implement as much,
    * or as little, of the service object's public methods as needed. A
    * dynamic proxy created by this method can be passed between JVMs, if
    * needed.
    * <br><i><u>NB</u>:</i> methods can be invoked either synchronously, or
    * asynchronously. The difference depends simply on the type of method
    * return specified. If the actual type of the return is used in the
    * interface, the method will block until completion as expected. However,
    * if a <a href=http://download.oracle.com/javase/6/docs/api/java/util/concurrent/Future.html>
    * java.util.concurrent.Future</a> is specified, the invocation will
    * return immediately, with the Future object. The future can be
    * periodically checked to see when the invocation is done, and get the
    * result. This is <i>very useful</i> for methods which require lengthy
    * time to complete, so as not to delay other thread processing.
    * @param object A reference to the sending service, the receiving
    * service, or other remote service/controller obtained using its cajo
    * reference
    * @param objectInterface The class of the interface to be implemented
    * <i>(e.g. somepkg.SomeInterface.class)</i>
    * @return An object implementing the interface provided, yet passing
    * the function invocations directly onto the object
    * <br><i><u>NB</u>:</i> If any of the arguments passed onto a homeService
    * invocation are not serialisable, or the result is not; those objects
    * will be transparently replaced with dynamic proxies, implementing all
    * of the remote object's interfaces. Hence the practice of using
    * interfaces, rather than objects, in method signatures is recommended.
    * A local dynamic proxy can be created with a local interface, on a
    * dynamic proxy of a remote object.
    */
   @SuppressWarnings("unchecked") // sigh...
   protected final <T> T proxy(Object object, Class objectInterface) {
      return (T)gnu.cajo.utils.extra.TransparentItemProxy.
         getItem(object, new Class[] { objectInterface });
   }
   /**
    * This method provides a means to identify this proxy.
    * @return An identifier <i>(not a description)</i> of the proxy
    */
   public String toString() { return "AbstractProxy"; }
   public void init(Object localService, gnu.cajo.Cajo cajo) {
      this.localService = localService;
      this.cajo = cajo;
   }
}
