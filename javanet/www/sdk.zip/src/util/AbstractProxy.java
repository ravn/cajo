package util;

/*
 * A base proxy class for a cajo grail server.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This class is released into the public domain.
 * Written by John Catherino
 */

/**
 * The proxy is a piece of executable code, sent from one service to run
 * locally at another service. It is the logical converse of the controller
 * object. It is normally used either when a client has to interact
 * frequently with a service, so as to minimise network traffic; or if the
 * target service operates operates on large data sets, to prevent having to
 * send the data over the network.<br>
 * <i><u>NB</u>:</i> not all service objects accept proxies, as a malicious
 * proxy could crash the service JVM e.g. by excessive memory allocation.
 * They are primarily accepted in well known domains, where the proxies are
 * trusted, or whose class definitions are in the codebase of the server.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public abstract class AbstractProxy implements IProxy {
   /**
    * The reference to the remote service from which the proxy was sent. It
    * is used to make asynchronous callbacks to the sending service.
    */
   protected final Object homeService;
   /**
    * The local reference to the remote service to which the proxy was sent.
    * It is used to autonomously interact with the target service.
    */
   protected transient Object localService;
   /**
    * A reference to the local server's cajo reference, with which the proxy
    * may look up other services, or even export itself.
    */
   protected transient gnu.cajo.Cajo cajo;
   /**
    * The constructor simply assigns the remote service reference.
    * @param homeService A remote reference to the sending service, over
    * which the proxy may asynchronously communicate with it
    */
   protected AbstractProxy(Object homeService) {
      this.homeService = homeService;
   }
   /**
    * This method allows subclasses of AbstractProxy to dynamically cast a
    * remote or local service reference into an interface of its
    * choice.
    * @param service A reference to sending service, or the local one
    * @param serviceInterface The class of the interface to be implemented
    * <i>(e.g. somepkg.SomeInterface.class)</i>
    * @return An object implementing the interface provided, yet passing
    * the function invocations directly onto the service object
    */
   @SuppressWarnings("unchecked") // sigh...
   protected final <T> T proxy(Object service, Class serviceInterface) {
      return (T)gnu.cajo.utils.extra.TransparentItemProxy.
         getItem(service, new Class[] { serviceInterface });
   }
   public void init(Object localService, gnu.cajo.Cajo cajo) {
      this.localService = localService;
      this.cajo = cajo;
   }
}
