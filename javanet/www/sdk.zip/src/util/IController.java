package util;

/*
 * The base interface for a controller for a cajo grail controller.
 * The cajo project: https://cajo.dev.java.net
 * For issues or suggestions mailto:cajo@dev.java.net
 * This interface is released into the public domain.
 * Written by John Catherino
 */

/**
 * This interface defines the canonical functions expected to be furnished
 * by <i>all</i> <a href=https://cajo.dev.java.net>cajo</a> controllers.
 * As a receiving object needs to know the controller's interface, or at
 * least part of it; typically receivers need to be custom-built to handle
 * specific types of controllers. <i>(much as to use its sending service)</i>
 * <p>Controllers may be passed between services, however, they
 * normally need to be sent wrapped in a java.rmi.MarshalledObject. The
 * receiver would then call the get() method, to extract the controller
 * object. This is necessary to preserve the information necessary for the
 * client to find the needed remote class definitions.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public interface IController {
   /**
    * This method is called by clients, to get a standardised html encoded
    * destription of the controller's functions. The format is invariant,
    * to allow automated parsing, if desired.
    * @return A detailed description of the functionality of the controller
    */
   String getDescription();
   /**
    * This method is normally called by a graphical client, to get the view
    * component associated with this controller, to display in its own frame.
    * @return AbstractView A graphical component which can then
    * be consolidated into any container for viewing.<br><i><u>NB</u>:</i>
    * The method <i>may</i> return null, if the controller has no view. Whilst
    * permitted, doing this <i>will</i> mess up use by the Applet/WebStart
    * {@link util.Client Client}, which <i>must</i> assume the controller has
    * a default view.
    * @throws java.io.IOException If the necessary UI resource files
    * cannot be found.
    */
   AbstractView getView() throws java.io.IOException;
   /**
    * This method is invoked only once, by the receiving service upon arrival.
    * It can be overridden to perform additional initialisation. However, if
    * this method is overridden, be sure to first call
    * super.init(cajo);. This method will <i>not</i> be called by the
    * util.Client object, as it has no cajo object.
    * @param cajo The server's cajo reference, with which the controller may
    * look up other services, or even export itself
    */
   void init(gnu.cajo.Cajo cajo);
}
