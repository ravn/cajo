package cajo.sdk;

/* Copyright 2010 John Catherino
 * The cajo project: https://cajo.dev.java.net
 *
 * Licensed under the Apache Licence, Version 2.0 (the "Licence"); you may
 * not use this file except in compliance with the licence. You may obtain a
 * copy of the licence at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the licence is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * This internal use only class provides the foundation for building {@link
 * AbstractService service}, {@link AbstractController controller} and
 * {@link AbstractAgent agent} objects.
 */
abstract class AbstractObject {
   /**
    * The default constructor performs no function.
    */
   protected AbstractObject() {}
   /**
    * This utility function dynamically casts a remote service, sent agent,
    * or local controller reference, into a local interface. The provided
    * interface can implement as much, or as little, of the provided object's
    * public methods <i>(instance and static)</i>as needed. A dynamic proxy
    * created by this method can be passed between JVMs, if needed.
    * <br><i><u>NB</u>:</i> methods can be invoked either synchronously, or
    * asynchronously. The difference depends simply on the type of method
    * return specified. If the actual type of the return is used in the
    * interface, the method will block until completion as expected. However,
    * if a <a href=http://download.oracle.com/javase/6/docs/api/java/util/concurrent/Future.html>
    * java.util.concurrent.Future</a> is specified, the invocation will
    * return immediately, with the Future object. The future can be
    * periodically checked to see when the invocation is done, and get the
    * result. This is <i>very useful</i> for methods which require lengthy
    * time to complete, so as not to delay other thread processing.
    * @param <T> The local interface to be implemented by the returned
    * dynamic proxy
    * @param object A reference to a remote service, received controller, or
    * sent agent, typically obtained by using the cajo reference
    * @param localInterface The local class of an interface of interest
    * <i>(e.g. somepkg.SomeInterface.class)</i>
    * @return An object implementing the interface provided, yet passing
    * the method invocations directly onto the object reference
    * <br><i><u>NB</u>:</i> If any of the arguments passed onto a remote
    * invocation are not serialisable, or the result is not; those objects
    * will be transparently replaced with dynamic proxies, implementing all
    * of the remote object's interfaces. Hence the practice of using
    * interfaces, rather than objects, in method signatures is recommended.
    * br>A local dynamic proxy can be created with a local interface, on a
    * dynamic proxy of a remote object.
    */
   @SuppressWarnings("unchecked") // sigh...
   protected static final <T> T proxy(Object object, Class<?> localInterface) {
      return (T)gnu.cajo.utils.extra.TransparentItemProxy.
         getItem(object, new Class[] { localInterface });
   }
   /**
    * This utility function will fetch a service reference from a remote
    * server.
    * @param host The host name or IP address of the remote server machine
    * @param port The TCP port number on which the remote server is operating
    * @param name The name of the service object to get
    * @return A remote reference to the named service object
    * @throws java.net.MalformedURLException If the host name is improperly
    * formatted
    * @throws java.rmi.NotBoundException If the named service is not
    * currently available
    */
   protected static final Object getService(String host, int port, String name)
      throws java.net.MalformedURLException, java.rmi.NotBoundException {
      try {
         return java.rmi.Naming.lookup("//" + host + ':' + port + '/' + name);
      } catch(java.rmi.RemoteException x) { return null; }
   }
}
