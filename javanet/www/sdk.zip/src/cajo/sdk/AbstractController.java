package cajo.sdk;

/* Copyright 2010 John Catherino
 * The cajo project: https://cajo.dev.java.net
 *
 * Licensed under the Apache Licence, Version 2.0 (the "Licence"); you may
 * not use this file except in compliance with the licence. You may obtain a
 * copy of the licence at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the licence is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * The controller is the smart go-between for its serice object. It is used
 * primarily to offload server workload and local storage related to the
 * support of the client. As a controller object must know its service in
 * detail, typically a controller belongs exclusively to one service.
 * <i><u>NB</u>:</i> Much as with service objects, a controller should
 * assume that it will be used by multiple service threads, <i>concurrently,</i>
 * therefore synchronisation of non-threadsafe code regions is essential.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public abstract class AbstractController extends AbstractReference
   implements IController {
   /**
    * A reference to the local server's cajo object, with which the
    * controller may look up other services, to fulfill its functionality
    * if needed. It can also be used to export objects as services on its
    * hosted machine. This can be useful for dynamically scaling service
    * instances.
    */
   protected transient gnu.cajo.Cajo cajo;
   /**
    * The constructor simply defines the canonical controller methods.
    */
   protected AbstractController() {
      descriptors.add(new Descriptor("getView",
         "This <i>canonical</i> method is normally called by a " +
         "graphical client, to get the view component associated with " +
         "this controller,  to display in its own frame.<br>*canonical " +
         "meaning it is <i>expected</i> to be implemented by <u>all</u> " +
         "services",
         null, // method accepts no arguments
         new String[] { // return
            "javax.swing.JComponent",
            "A graphical component which can then be consolidated into " +
            "any container for viewing. <i><u>NB</u>:</i> The method " +
            "<i>may</i> return null, if the controller has no view."
         }, new String[][] { // exceptions
            {
               "java.io.IOException",
               "If the needed UI resource objects cannot be found"
            },
         }
      ));
      descriptors.add(new Descriptor("init",
         "This <i>canonical</i> method is invoked only once, by the " +
         "receiving service, on arrival.",
         new String[][] { // arguments
            {
               "gnu.cajo.Cajo",
               "The receiver's cajo reference, with wich the controller " +
               "may look up other services to fulfill its functionality, " +
               "if needed"
            },
         }, null,   // this method returns no value
         NOEXCEPTION // this method throws no exceptions, it's local
      ));
   }
   /**
    * This method provides a means to identify this controller.
    * @return An identifier <i>(not a description)</i> of the controller
    */
   @Override
   public String toString() { return "AbstractController"; }
   @Override
   public void init(@SuppressWarnings("hiding") gnu.cajo.Cajo cajo) {
      if (this.cajo != null)
         throw new IllegalArgumentException("controller already initialised");
      this.cajo = cajo;
   }
}
