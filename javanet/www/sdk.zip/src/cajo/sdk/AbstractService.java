package cajo.sdk;

import gnu.cajo.invoke.Remote;
import gnu.cajo.utils.ItemServer;

/* Copyright 2010 John Catherino
 * The cajo project: https://cajo.dev.java.net
 *
 * Licensed under the Apache Licence, Version 2.0 (the "Licence"); you may
 * not use this file except in compliance with the licence. You may obtain a
 * copy of the licence at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the licence is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * The service is a publicly invocable ordinary Java object. All of its
 * public methods, either <i>instance or static,</i> can be invoked by remote
 * JVMs. It is recommended to use this class as a wrapper, exposing specific
 * methods of its internal utility objects. It is normally completely unaware
 * of the <a href=https://cajo.dev.java.net>cajo</a>
 * <a href=http://weblogs.java.net/blog/cajo/archive/2007/09/simple_interjvm.html>
 * grail</a> framework.
 * <br>It can use its <a href=https://cajo.dev.java.net/nonav/docs/gnu/cajo/Cajo.html>
 * Cajo</a> member reference to find and interact with other services. A
 * service being an atomic element of functionality, could belong to multiple
 * {@link AbstractService service}s.<br>
 * All service object instances must assume that they will be used in a
 * multi-threaded <i>(i.e. reentrant)</i> environment, therefore protection
 * of non-threadsafe code regions is essential.
 * @author <a href=http://wiki.java.net/bin/view/People/JohnCatherino>
 * John Catherino</a>
 */
public abstract class AbstractService extends AbstractReference
   implements IService {
   private final Object initArgs[];
   private final String controller, name;
   private Remote serviceRef;
   /**
    * This is the reference to the logged service. It is made accessible to
    * subclasses, to periodically change out the log stream, if necessary.
    */
   protected final Logger service;
   /**
    * The cajo reference is used by this service, and any received agents and
    * controllers, to look up other services needed to perform their
    * functionality, as needed.
    */
   protected final gnu.cajo.Cajo cajo;
   /**
    * The constructor will locally bind the service at its host under the
    * name provided, and join the <a href=http://weblogs.java.net/blog/cajo/archive/2007/09/simple_interjvm.html>
    * cajo federation</a>. The constructor can take arguments, there is no
    * artificial restriction that a service must have a no-arg constructor.
    * @param controller The class name of the <i>optional</i> {@link
    * AbstractController controller} to instantiate upon arrival at the
    * client JVM <i>(e.g. controller.Controller)</i> it can be either
    * hard-coded, read from a file, or a system property.<br>
    * <i><u>NB</u>:</i> The controller argument can be null, if the service
    * wishes to provide no controller, nor GUI for clients.
    * @param name The name under which to bind the service in the local
    * rmi registry. These services can be then accessed through their
    * registry URL <i>(e.g. //myhost:1198/main)</i>.<br>
    * <i><u>NB</u>:</i> If a service already exists under this name, this
    * service will replace it.
    * @param log The output stream to write the service invocation events,
    * if this argument is null, the events will be written to System.out
    * <br><i><u>NB</u>:</i> it is <i>highly</i> recommended to build oos
    * atop a BufferedOutputStream, and if a lot of invocations are being
    * logged, possibly a ZippedOutputStream as well. The stream could be from
    * a socket, if logging to another machine is desired. The same stream
    * can be used by multiple services.
    * @throws Exception if the service could not be successfully constructed,
    * normally for network configuration related issues
    */
   @SuppressWarnings("hiding") // we're defining controller and name here
   protected AbstractService(String controller, String name,
      java.io.ObjectOutputStream log) throws Exception {
      descriptors.add(new Descriptor("getController",
         "This <i>canonical</i> method is used to obtain a locally " +
         "running <i>smart</i> reference to the remote object. It allows " +
         "the server to offload some compute and memory load to the " +
         "client. It is not required for a client to request a service's " +
         "controller, and some services may not support controller objects " +
         "at all. However, requesting a service controller is considered " +
         "a <i>common courtesy.</i> Correspondingly, controllers should " +
         "take pains to minimise the compute and memory resources used of " +
         "the client.",
         null, // method accepts no arguments
         new String[] { // return
            "java.lang.Object", controller != null ?
            "A locally running object create a reference to the actual " +
            "controller object. The object can be saved to storage, or " +
            "passed to other remote JVMs, to provide controllers to other " +
            "services." :
            "This service furnishes no controller, the return will be null."
         }, null // only throws java.rmi.RemoteException
      ));
      descriptors.add(new Descriptor("acceptAgent",
         "This <i>canonical</i> method is used to install client or " +
         "remote service agents in this JVM. It allows local usage of the " +
         "service item in cases where network traffic could be greatly " +
         "reduced.",
         new String[][] { // arguments
            {
               "java.lang.Object",
               "The client/remote service agent object. Its <tt>init</tt> " +
               "method will be called, passing in a local reference to " +
               "the service object"
            },
         }, new String[] { // return
            "Object", System.getProperty("java.rmi.server.useCodebaseOnly").
            equals("false") ?
            "A remote reference to the agent object on which the sender " +
            "may communicate with it, in whatever manner it wishes." :
            "This service does <i><u>not</u></i> accept agents."
         }, new String[][] { // exceptions
            {
               "java.lang.ClassNotFoundException",
               "If the service does not accept agents"
            }, {
               "java.lang.NoSuchMethodException",
               "If the agent does not implement a public <tt>init</tt> " +
               "method <i>(static or instance)</i>"
            }, {
               "java.lang.Exception",
               "Should the agent reject the initialisation, or for any " +
               "agent specific reasons"
            }, REMOTEEXCEPTION, // throws java.rmi.RemoteException too
         }
      ));
      this.controller = controller;
      this.name = name;
      cajo = AbstractServer.cajo;
      service = new Logger (this, log); // wrap service for logging
      initArgs = new Object[] { cajo, service };
      restart(); // actually just starting up for the first time ;)
   }
   /**
    * This utility function will fetch a service reference from a remote
    * server.
    * @param host The host name or IP address of the remote server machine
    * @param port The TCP port number on which the remote server is operating
    * @param name The name of the service object to get
    * @return A remote reference to the named service object
    * @throws java.rmi.NotBoundException If the named service is not
    * currently available
    */
   protected static final Object getService(String host, int port, String name)
      throws java.rmi.NotBoundException {
      try { return Remote.getItem("//" + host + ':' + port + '/' + name); }
      catch(java.rmi.RemoteException x) { return null; }
      catch(java.io.IOException x)      { return null; }
      catch(ClassNotFoundException x)   { return null; }
      catch(InstantiationException x)   { return null; }
      catch(IllegalAccessException x)   { return null; }
   }
   /**
    * This utility function is used to request a {@link AbstractController
    * controller} object from a remote service. The service reference is
    * typically looked up using the
    * <a href=https://cajo.dev.java.net/nonav/docs/gnu/cajo/Cajo.html#lookup(java.lang.Class)>
    * cajo</a> object.
    * <br><i><u>NB</u>:</i> Accepting of controllers is disabled by default.
    * To enable acceptance of controllers and agents uncomment the
    * <tt>ItemServer.acceptProxies()</tt> line in the main Server class.
    * @param service The remote reference to the service object from which
    * to request its controller
    * @return A local reference to the controller operating in this JVM,
    * or null, if the service does not furnish a controller -- this reference
    * can be wrapped with a {@link Logger Logger}, for debug purposes
    * @throws java.rmi.RemoteException For network errors, or network
    * configuration issues
    * @throws Exception if the received controller rejects its initialisation
    * for some controller-specific reason
    */
   protected static final Object getController(Object service)
      throws Exception {
      Object controller = Remote.invoke(service, "getController", null);
      if (controller == null) return null;
      Remote.invoke(controller, "init", AbstractServer.cajo);
      return controller;
   }
   /**
    * This method disconnects the service from further client use. The
    * service will no longer be usable by clients. It can be put back
    * into service by calling its restart method.<br>
    * <i><u>NB</u>:</i> If the service has accepted any agents, those agents
    * will <i>continue</i> to operate, since they have a local reference to
    * the service.
    * @throws java.rmi.NoSuchObjectException If the service has already been
    * unexported.
    */
   protected final void shutdown() throws java.rmi.NoSuchObjectException {
      ItemServer.unbind(name);
      serviceRef.unexport(true);
   }
   /**
    * This method will make the service available again for remote use
    * following a shutdown call.
    * @throws java.io.IOException For network related issues.
    */
   protected final void restart() throws java.io.IOException {
      serviceRef = new Remote(service); // make service remotely callable
      ItemServer.bind(serviceRef, name); // publish service for remote access
      cajo.export(this, service); // add service to cajo federation
   }
   /**
    * This method is used to send a {@link AbstractAgent agent} object to a
    * remote service.
    * @param agent The class name of the agent to instantiate on arrival
    * at the remote service JVM <i>(e.g. agent.Agent)</i> it can be either
    * hard-coded, read from a file, or a system property
    * @param service The remote reference of the service to which to send
    * this agent
    * @return A remote reference to the agent operating at the target service
    * -- this reference is can be wrapped with a {@link Logger Logger}, for
    * debug purposes
    * @throws Exception If the remote service does not accept agent objects
    */
   @SuppressWarnings("hiding")
   protected final Object sendAgent(String agent, Object service)
      throws Exception {
      ProxyLoader pl = new ProxyLoader(agent, serviceRef);
      return Remote.invoke(service, "acceptAgent", pl);
   }
   /**
    * This utility function returns the names of the services currently
    * bound by this JVM. It is public, so that it may be called from other
    * remote objects. Even static methods are remotely callable in cajo, they
    * can be included in a client's local proxy interface as well.
    * @return All of the services currently available for use
    */
   public static final String[] services() { return ItemServer.list(); }
   /**
    * This utility function returns a remote service reference by name from
    * the server furnishing this service. Even static methods are remotely
    * callable in cajo, they can be included in a client's local proxy
    * interface as well.
    * @param name The name of the service reference to fetch
    * @return A remote reference to the named service
    * @throws java.rmi.NotBoundException If the service is not currently
    * available
    */
   public static final Object getService(String name)
      throws java.rmi.NotBoundException {
      return ItemServer.lookup(name);
   }
   /**
    * This method is called just before the service goes live on the network.
    * It was intended to signal the service to start any internal processing
    * threads. Better is to start internal processing threads in the service
    * constructor. This method now performs no function.
    * @deprecated The fundamental problem with this method is that it is
    * public, meaning it can also be called by clients. Without proper
    * safeguarding, that could result in potentially serious problems.
    */
   @Deprecated
   public static final void startThread() {}
   /**
    * This method provides a means to identify this service.
    * @return An identifier <i>(not a description)</i> of the service
    */
   @Override
   public String toString() { return "AbstractService"; }
   @Override
   public final Object getController() { // support hot-swapping at runtime
      return controller == null ? null :
         new ProxyLoader(controller, serviceRef);
   }
   @Override
   public Object acceptAgent(Object agent) throws Exception {
      Remote.invoke(agent, "init", initArgs);
      return new Remote(agent).clientScope();
   }
}
