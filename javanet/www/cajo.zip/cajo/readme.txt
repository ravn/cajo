Note: This software is OSI Certified Open Source Software.
OSI Certified is a certification mark of the Open Source Initiative.

The home page for this project can be found at:

	https://cajo.dev.java.net

There you will find considerable additional information, and a tutorial.
Also a community of users, and forums on which to discuss and collaborate.
Please give it a visit.
