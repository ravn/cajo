
Release 1.83
01-May-06

The cajo project transparent distributed computing library

Home page: https://cajo.dev.java.net

Copyright (C) 1999 John Catherino

This library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation, at version 2.1 of the license, or any
later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU Lesser General Public License for more details.

You can receive a copy of the GNU Lesser General Public License from the
FSF website, http://fsf.org/licenses/lgpl.html or via snail mail:

   Free Software Foundation Inc.
   51 Franklin Street,
   Boston MA 02111-1301, USA
