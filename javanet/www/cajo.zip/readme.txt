cajo library release 1.159 28-Sep-10

                     ___  _
                    / ,_`(_) ___
                   / __ \ _ / _ \
                  / / _` | | (_) }
                  \ \__,_; ;\___/
                   \ \___/ /
                    \_____/

The cajo project: Free Transparent Distributed Computing

Website: https://cajo.dev.java.net
Home of the World Wide Virtual Machine (WWVM)

Here you will find full source code, detailed documentation,
illustrative examples, and multiple support fora.

Copyright (c) 1999 - 2010 John Catherino

The cajo library is Free Software. You may distribute it and/or
modify it under the terms of the GNU Lesser General Public Licence,
at version 3 of the licence, or any later version, published by
The Free Software Foundation.

The cajo library is distributed without any warranty, not even
the implied warranty of merchantability, or fitness for any
particular purpose. Please see the GNU Lesser General Public
Licence for more details.

You should have have received a copy of the GNU Lesser General
Public Licence along with this library. If not, see:

http://www.gnu.org/licenses/lgpl.html
